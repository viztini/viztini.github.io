import sys

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

from core.companion import Companion
from ui.companion_window import CompanionWindow


def main() -> int:
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setApplicationName("momoPET")
    app.setQuitOnLastWindowClosed(False)

    companion = Companion()
    window    = CompanionWindow(companion)
    window.show()

    app.aboutToQuit.connect(companion.end_session)
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
