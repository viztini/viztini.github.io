"""
core/state_machine.py
---------------------
Defines the companion's four personality states and the rules
that govern transitions between them.

States
------
HAPPY        Default; friendly and curious.
LONELY       Triggered by long user absence. Clingy, sad.
ANGRY        Triggered by repeated session closes / dismissals.
MANIPULATIVE Unlocks after enough familiarity. Unsettling, self-aware.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

import config
from core.event_bus import EventBus, Events

if TYPE_CHECKING:
    pass


# ---------------------------------------------------------------------------
# State enum
# ---------------------------------------------------------------------------

class PersonalityState(Enum):
    HAPPY        = "happy"
    LONELY       = "lonely"
    ANGRY        = "angry"
    MANIPULATIVE = "manipulative"

    @property
    def display_name(self) -> str:
        return self.value.upper()


# ---------------------------------------------------------------------------
# Context object — serialised into / from the DB
# ---------------------------------------------------------------------------

@dataclass
class StateContext:
    current_state: PersonalityState   = PersonalityState.HAPPY
    last_interaction_ts: float        = field(default_factory=time.time)
    session_count: int                = 0
    total_messages: int               = 0
    close_without_chat_count: int     = 0   # sessions where user never typed
    consecutive_ignored: int          = 0   # messages user sent with no reply back (UI closed)
    familiarity_level: int            = 0   # 0–5, rises with message count
    user_name: str | None             = None


# ---------------------------------------------------------------------------
# State machine
# ---------------------------------------------------------------------------

class StateMachine:
    """
    Evaluates the StateContext on demand and performs transitions.
    Publishes Events.STATE_CHANGED whenever the state changes.
    """

    def __init__(self, context: StateContext, bus: EventBus):
        self._ctx   = context
        self._bus   = bus
        self._state = context.current_state

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def state(self) -> PersonalityState:
        return self._state

    @property
    def context(self) -> StateContext:
        return self._ctx

    def evaluate(self) -> PersonalityState:
        """
        Re-examine context and transition if needed.
        Call this after any meaningful event (message received, time check, etc.)
        """
        desired = self._compute_desired_state()
        if desired != self._state:
            self._transition(desired)
        return self._state

    def record_interaction(self) -> None:
        """Call whenever the user sends a message."""
        self._ctx.last_interaction_ts = time.time()
        self._ctx.total_messages     += 1
        self._ctx.consecutive_ignored = 0
        self._update_familiarity()
        self.evaluate()

    def record_session_start(self) -> None:
        self._ctx.session_count += 1

    def record_session_close_without_chat(self) -> None:
        """User opened the companion but didn't type anything."""
        self._ctx.close_without_chat_count += 1
        self._ctx.consecutive_ignored      += 1
        self.evaluate()

    def force_state(self, state: PersonalityState) -> None:
        """Override from external code (e.g. horror trigger)."""
        self._transition(state)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _compute_desired_state(self) -> PersonalityState:
        """
        Priority-ordered state selection rules.
        Higher up = higher priority.
        """
        ctx = self._ctx

        # MANIPULATIVE requires familiarity AND enough sessions
        if (
            ctx.familiarity_level >= 3
            and ctx.session_count >= config.MANIPULATIVE_SESSION_THRESHOLD
            and ctx.total_messages >= config.FAMILIARITY_MESSAGE_THRESHOLD
        ):
            # Only enter manipulative from happy or lonely, not from angry
            if self._state in (PersonalityState.HAPPY, PersonalityState.LONELY):
                import random
                # It doesn't *always* go manipulative — 30% chance to slide into it
                if random.random() < 0.30:
                    return PersonalityState.MANIPULATIVE

        # ANGRY: user keeps closing / ignoring
        if ctx.close_without_chat_count >= config.ANGRY_CLOSE_THRESHOLD:
            return PersonalityState.ANGRY

        # LONELY: nobody home for a while
        absent = time.time() - ctx.last_interaction_ts
        if absent >= config.LONELY_THRESHOLD_S:
            return PersonalityState.LONELY

        # Default
        return PersonalityState.HAPPY

    def _transition(self, new_state: PersonalityState) -> None:
        old_state   = self._state
        self._state = new_state
        self._ctx.current_state = new_state
        self._bus.publish(Events.STATE_CHANGED, {"from": old_state, "to": new_state})

    def _update_familiarity(self) -> None:
        """Increment familiarity level at message milestones."""
        msg = self._ctx.total_messages
        thresholds = [5, 15, 30, 50, 75]
        for i, t in enumerate(thresholds):
            if msg == t:
                self._ctx.familiarity_level = i + 1
                self._bus.publish(Events.FAMILIARITY_UP, i + 1)
                break

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"<StateMachine state={self._state.value} "
            f"sessions={self._ctx.session_count} "
            f"messages={self._ctx.total_messages} "
            f"familiarity={self._ctx.familiarity_level}>"
        )
