from collections import defaultdict
from typing import Callable, Any


class EventBus:
    def __init__(self):
        self._listeners: dict[str, list[Callable]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def subscribe(self, event: str, callback: Callable[[Any], None]) -> None:
        """Register *callback* to be called whenever *event* is published."""
        if callback not in self._listeners[event]:
            self._listeners[event].append(callback)

    def unsubscribe(self, event: str, callback: Callable[[Any], None]) -> None:
        """Remove a previously registered callback."""
        try:
            self._listeners[event].remove(callback)
        except ValueError:
            pass

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def publish(self, event: str, data: Any = None) -> None:
        for callback in list(self._listeners[event]):
            try:
                callback(data)
            except Exception as exc:  # noqa: BLE001
                print(f"[EventBus] Error in handler for '{event}': {exc}")

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def once(self, event: str, callback: Callable[[Any], None]) -> None:
        """Subscribe *callback* to fire exactly once, then auto-unsubscribe."""
        def _wrapper(data: Any) -> None:
            callback(data)
            self.unsubscribe(event, _wrapper)
        self.subscribe(event, _wrapper)

    def clear(self, event: str = None) -> None:
        """Remove all listeners for *event*, or all events if None."""
        if event:
            self._listeners.pop(event, None)
        else:
            self._listeners.clear()


# ---------------------------------------------------------------------------
# Canonical event names — import these rather than using raw strings
# ---------------------------------------------------------------------------

class Events:
    # State machine
    STATE_CHANGED       = "state:changed"       # data: {"from": State, "to": State}
    FAMILIARITY_UP      = "state:familiarity_up" # data: int (new level)

    # Chat / dialogue
    CHAT_USER_MESSAGE   = "chat:user_message"   # data: str
    CHAT_RESPONSE_READY = "chat:response_ready" # data: {"text": str, "state": State}
    CHAT_THINKING       = "chat:thinking"       # data: None (show spinner)
    CHAT_ERROR          = "chat:error"          # data: str (error message)

    # Horror system
    HORROR_FIRE         = "horror:fire"         # data: HorrorEvent dataclass
    HORROR_SHAKE        = "horror:shake"        # data: None
    HORROR_GLITCH       = "horror:glitch"       # data: float (intensity 0-1)
    HORROR_POPUP        = "horror:popup"        # data: str (message text)
    HORROR_STARE        = "horror:stare"        # data: None (red-eye stare)

    # Companion window
    COMPANION_BLINK     = "companion:blink"     # data: None
    COMPANION_EMOTE     = "companion:emote"     # data: str (emote name)
    COMPANION_DRAG      = "companion:drag"      # data: {"x": int, "y": int}

    # Application lifecycle
    APP_SESSION_START   = "app:session_start"   # data: int (session number)
    APP_SESSION_END     = "app:session_end"     # data: None
    APP_QUIT_REQUESTED  = "app:quit_requested"  # data: None
