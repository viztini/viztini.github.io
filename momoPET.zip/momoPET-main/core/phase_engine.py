"""
core/phase_engine.py
--------------------
Timed phase progression. MOMO gets worse the longer the app runs.

Phase 1 (0-10 min):   Innocent. Cheerful. Building false security.
Phase 2 (10-30 min):  Observant. Mentions your username, watches apps.
Phase 3 (30-60 min):  Aggressive. Glitch jitter, desktop file drops.
Phase 4 (60+ min):    Broken. Heavy corruption, floating eye, full glitch.
"""
from __future__ import annotations
import time
from enum import IntEnum
from core.event_bus import EventBus


class Phase(IntEnum):
    INNOCENT    = 1
    OBSERVANT   = 2
    AGGRESSIVE  = 3
    BROKEN      = 4


class Events:
    PHASE_CHANGED = "phase:changed"   # data: Phase


class PhaseEngine:
    THRESHOLDS = {
        Phase.INNOCENT:   0,
        Phase.OBSERVANT:  10 * 60,
        Phase.AGGRESSIVE: 30 * 60,
        Phase.BROKEN:     60 * 60,
    }

    def __init__(self, bus: EventBus):
        self._bus       = bus
        self._start_ts  = time.time()
        self._phase     = Phase.INNOCENT
        self._callbacks: list = []

    @property
    def phase(self) -> Phase:
        return self._phase

    def tick(self) -> Phase:
        elapsed = time.time() - self._start_ts
        new = Phase.INNOCENT
        for p in (Phase.BROKEN, Phase.AGGRESSIVE, Phase.OBSERVANT, Phase.INNOCENT):
            if elapsed >= self.THRESHOLDS[p]:
                new = p
                break
        if new != self._phase:
            self._phase = new
            self._bus.publish("phase:changed", new)
        return self._phase

    def elapsed_seconds(self) -> float:
        return time.time() - self._start_ts

    def glitch_intensity(self) -> float:
        """0.0 – 1.0 glitch level based on current phase."""
        return {
            Phase.INNOCENT:   0.0,
            Phase.OBSERVANT:  0.15,
            Phase.AGGRESSIVE: 0.55,
            Phase.BROKEN:     1.0,
        }[self._phase]

    def jitter_px(self) -> int:
        """Sprite vertex-jitter pixel amount."""
        return {
            Phase.INNOCENT:   0,
            Phase.OBSERVANT:  1,
            Phase.AGGRESSIVE: 5,
            Phase.BROKEN:     14,
        }[self._phase]
