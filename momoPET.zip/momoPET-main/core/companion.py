"""core/companion.py — Orchestrator. Now includes PhaseEngine."""
from __future__ import annotations
import time
from typing import Optional
import config
from core.event_bus import EventBus, Events
from core.state_machine import StateMachine, StateContext
from core.phase_engine import PhaseEngine
from memory.database import Database
from memory.memory_manager import MemoryManager
from ai.dialogue_manager import DialogueManager
from utils.helpers import extract_name_from_text


class Companion:
    def __init__(self):
        self.bus    = EventBus()
        self.db     = Database(config.DB_PATH)
        self.memory = MemoryManager(self.db)
        saved_ctx   = self.memory.load_state_context()
        self.sm     = StateMachine(saved_ctx, self.bus)
        self.phase  = PhaseEngine(self.bus)
        self.dialogue = DialogueManager(self.bus, self.memory, self.sm)
        self.bus.subscribe(Events.CHAT_USER_MESSAGE, self._on_user_message)
        self.bus.subscribe(Events.APP_QUIT_REQUESTED, self._on_quit)
        self._session_started = False

    def start_session(self) -> None:
        self._session_started = True
        self.sm.record_session_start()
        self.memory.save_state_context(self.sm.context)
        self.bus.publish(Events.APP_SESSION_START, self.sm.context.session_count)

    def end_session(self) -> None:
        if not self._session_started: return
        if self.db.get_message_count() == 0:
            self.sm.record_session_close_without_chat()
        self.memory.save_state_context(self.sm.context)
        self.memory.end_session()

    def _on_user_message(self, text: str) -> None:
        if not self.sm.context.user_name:
            name = extract_name_from_text(text)
            if name:
                self.sm.context.user_name = name
                self.memory.set_user_name(name)
        self.dialogue.send(text)

    def _on_quit(self, _) -> None:
        self.end_session()

    @property
    def name(self) -> str:           return config.COMPANION_NAME
    @property
    def state(self):                  return self.sm.state
    @property
    def user_name(self) -> Optional[str]: return self.sm.context.user_name
    @property
    def session_count(self) -> int:   return self.sm.context.session_count
