"""
assets/sprite_generator.py
---------------------------
MOMO — PSX / Win95 / WinXP pre-rendered 3D aesthetic.

Techniques used to nail the era:
  - Flat-shaded polygon facets (discrete shading zones, no smooth gradients)
  - 4x4 Bayer ordered dithering at every shade boundary
  - Hard single-source specular highlight
  - Strictly limited palette (8 shades per state)
  - Nearest-neighbour 2x downscale → upscale for that chunky pixel texture
  - Posterised shadows with visible dither grain
  - Scanline ghost noise layer (subtle)

Run:  python assets/sprite_generator.py
"""

from __future__ import annotations
import math, random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

W, H        = 150, 200
FRAMES      = 4
BOB         = [0, -3, -5, -3]
SPRITES_DIR = Path(__file__).parent / "sprites"

# ---------------------------------------------------------------------------
# Bayer 4×4 ordered dithering matrix  (values 0-15, threshold 0-1)
# ---------------------------------------------------------------------------
BAYER = [
    [ 0,  8,  2, 10],
    [12,  4, 14,  6],
    [ 3, 11,  1,  9],
    [15,  7, 13,  5],
]

def bayer_threshold(x: int, y: int) -> float:
    return BAYER[y & 3][x & 3] / 16.0


def dither_pixel(x: int, y: int, col_a: tuple, col_b: tuple, t: float) -> tuple:
    """Return col_a or col_b based on Bayer dithering at blend fraction t."""
    return col_a if bayer_threshold(x, y) < t else col_b


# ---------------------------------------------------------------------------
# Limited palettes per state  (8 discrete shades each)
# ---------------------------------------------------------------------------
PAL = {
    "happy": {
        "spec":   (255, 248, 255, 255),   # specular white
        "hi":     (215, 175, 255, 255),   # bright lit face
        "mid_hi": (172, 112, 252, 255),   # mid-lit face
        "mid":    (132, 72,  210, 255),   # centre base
        "shadow": (82,  35,  155, 255),   # shadow face
        "dark":   (44,  12,  90,  255),   # dark edge
        "outline":(18,  4,   38,  255),   # outline
        "eye_w":  (240, 232, 255, 255),   # eye white
        "eye_c":  (120, 0,   220, 255),   # iris colour
        "pupil":  (8,   0,   18,  255),
        "tent":   (100, 52,  180, 255),
        "tent_d": (55,  20,  110, 255),
        "mouth":  (200, 140, 255, 255),
    },
    "lonely": {
        "spec":   (230, 240, 255, 255),
        "hi":     (170, 185, 255, 255),
        "mid_hi": (120, 130, 220, 255),
        "mid":    (82,  88,  175, 255),
        "shadow": (48,  52,  120, 255),
        "dark":   (22,  24,  70,  255),
        "outline":(8,   8,   30,  255),
        "eye_w":  (210, 215, 255, 255),
        "eye_c":  (60,  80,  210, 255),
        "pupil":  (5,   5,   20,  255),
        "tent":   (70,  75,  160, 255),
        "tent_d": (38,  40,  100, 255),
        "mouth":  (140, 150, 220, 255),
    },
    "angry": {
        "spec":   (255, 220, 210, 255),
        "hi":     (255, 160, 140, 255),
        "mid_hi": (210, 70,  60,  255),
        "mid":    (165, 30,  30,  255),
        "shadow": (95,  10,  10,  255),
        "dark":   (45,  2,   2,   255),
        "outline":(20,  0,   0,   255),
        "eye_w":  (255, 180, 180, 255),
        "eye_c":  (230, 10,  10,  255),
        "pupil":  (15,  0,   0,   255),
        "tent":   (140, 25,  25,  255),
        "tent_d": (80,  8,   8,   255),
        "mouth":  (220, 50,  50,  255),
    },
    "manipulative": {
        "spec":   (245, 220, 255, 255),
        "hi":     (195, 120, 255, 255),
        "mid_hi": (140, 60,  220, 255),
        "mid":    (88,  22,  155, 255),
        "shadow": (48,  8,   95,  255),
        "dark":   (20,  2,   45,  255),
        "outline":(8,   0,   20,  255),
        "eye_w":  (230, 180, 255, 255),
        "eye_c":  (190, 0,   255, 255),
        "pupil":  (8,   0,   15,  255),
        "tent":   (75,  15,  140, 255),
        "tent_d": (38,  5,   80,  255),
        "mouth":  (185, 55,  230, 255),
    },
}


# ---------------------------------------------------------------------------
# Core drawing helpers
# ---------------------------------------------------------------------------

def _fill_dithered(img: Image.Image, mask_fn, col_a: tuple, col_b: tuple, t: float):
    """Fill pixels where mask_fn(x,y) is True using dithered blend of a→b."""
    px = img.load()
    for y in range(H):
        for x in range(W):
            if mask_fn(x, y):
                px[x, y] = dither_pixel(x, y, col_a, col_b, t)


def _draw_polygon_flat(draw: ImageDraw.ImageDraw, pts, colour):
    draw.polygon(pts, fill=colour)


def _draw_outline_polygon(draw: ImageDraw.ImageDraw, pts, colour, width=2):
    draw.polygon(pts, outline=colour)
    draw.line(pts + [pts[0]], fill=colour, width=width)


# ---------------------------------------------------------------------------
# Mantle — drawn as flat-shaded polygon facets (PSX style)
# ---------------------------------------------------------------------------

def _mantle_points(cx, cy, rx, ry, n=10):
    """Return n points of an ellipse (polygon approximation)."""
    return [
        (int(cx + rx * math.cos(2*math.pi*i/n)),
         int(cy + ry * math.sin(2*math.pi*i/n)))
        for i in range(n)
    ]


def _draw_mantle(img: Image.Image, draw: ImageDraw.ImageDraw, p: dict, yo: int):
    cx, cy = 75, 72 + yo
    rx, ry = 46, 42

    # ---- Base fill (mid tone all over) ----
    all_pts = _mantle_points(cx, cy, rx, ry, n=12)
    draw.polygon(all_pts, fill=p["mid"])

    # ---- Top-left highlight face ----
    hi_pts = [
        (cx - 2, cy - ry),
        (cx - rx + 6, cy - ry // 2),
        (cx - rx // 3, cy - 4),
        (cx + 6,  cy - ry + 8),
    ]
    draw.polygon(hi_pts, fill=p["hi"])

    # ---- Right shadow face ----
    sh_pts = [
        (cx + rx // 3, cy - ry // 2),
        (cx + rx,      cy),
        (cx + rx - 4,  cy + ry // 2),
        (cx + 4,       cy + 6),
    ]
    draw.polygon(sh_pts, fill=p["shadow"])

    # ---- Bottom dark face ----
    dk_pts = [
        (cx - rx // 2, cy + 6),
        (cx + rx // 2, cy + 6),
        (cx + rx // 3, cy + ry),
        (cx - rx // 3, cy + ry),
    ]
    draw.polygon(dk_pts, fill=p["dark"])

    # ---- Dithered boundary: hi → mid ----
    def _in_hi_band(x, y):
        return (y < cy - 4 and x < cx + 8
                and _pt_in_ellipse(x, y, cx, cy, rx, ry))
    _fill_dithered(img, _in_hi_band, p["hi"], p["mid_hi"], 0.45)

    # ---- Dithered boundary: mid → shadow (right side) ----
    def _in_shadow_band(x, y):
        return (x > cx + rx // 4 and y > cy - ry // 3
                and _pt_in_ellipse(x, y, cx, cy, rx, ry))
    _fill_dithered(img, _in_shadow_band, p["mid"], p["shadow"], 0.5)

    # ---- Outline (hard PSX edge) ----
    draw.ellipse([cx-rx-1, cy-ry-1, cx+rx+1, cy+ry+1],
                 outline=p["outline"], width=2)

    # ---- Hard specular dot (top-left) ----
    sx, sy = cx - 14, cy - 20
    draw.ellipse([sx-7, sy-6, sx+7, sy+6], fill=p["spec"])
    # Bayer-dither the specular edge
    for dy in range(-9, 9):
        for dx in range(-9, 9):
            px2, py2 = sx + dx, sy + dy
            if 0 <= px2 < W and 0 <= py2 < H:
                d2 = dx*dx*0.7 + dy*dy
                if 36 < d2 < 80:
                    t = (d2 - 36) / 44.0
                    img.putpixel((px2, py2),
                                 dither_pixel(px2, py2, p["spec"], p["hi"], t))

    # ---- Mantle top bump ----
    draw.ellipse([cx-10, cy-ry-10, cx+10, cy-ry+8], fill=p["mid"])
    draw.ellipse([cx-9,  cy-ry-9,  cx+9,  cy-ry+7], fill=p["mid_hi"])
    draw.ellipse([cx-8,  cy-ry-8,  cx+8,  cy-ry+6], outline=p["outline"], width=1)


def _pt_in_ellipse(x, y, cx, cy, rx, ry):
    return ((x-cx)**2 / rx**2 + (y-cy)**2 / ry**2) <= 1.0


# ---------------------------------------------------------------------------
# Eyes — hard-edged with PSX specular
# ---------------------------------------------------------------------------

def _draw_eyes(draw: ImageDraw.ImageDraw, img: Image.Image, p: dict, yo: int,
               blink=False, wide=False, angry=False):
    positions = [(56, 65 + yo), (94, 65 + yo)]
    for (cx, cy) in positions:
        ro = 11 + (3 if wide else 0)

        # Outer dark socket
        draw.ellipse([cx-ro-2, cy-ro-2, cx+ro+2, cy+ro+2], fill=p["outline"])
        # Eye white
        draw.ellipse([cx-ro, cy-ro, cx+ro, cy+ro], fill=p["eye_w"])

        if blink:
            draw.rectangle([cx-ro+1, cy-3, cx+ro-1, cy+3], fill=p["outline"])
        else:
            ri = 7 + (2 if wide else 0)
            # Iris flat colour
            draw.ellipse([cx-ri, cy-ri, cx+ri, cy+ri], fill=p["eye_c"])
            # Dither iris edge into white
            for dy in range(-ri-3, ri+3):
                for dx in range(-ri-3, ri+3):
                    px2, py2 = cx+dx, cy+dy
                    if 0 <= px2 < W and 0 <= py2 < H:
                        d = math.sqrt(dx*dx+dy*dy)
                        if ri-1 < d < ri+3:
                            t = (d - (ri-1)) / 4.0
                            img.putpixel((px2, py2),
                                         dither_pixel(px2, py2, p["eye_c"], p["eye_w"], t))
            # Pupil
            rp = max(3, ri-3)
            draw.ellipse([cx-rp, cy-rp, cx+rp, cy+rp], fill=p["pupil"])
            # Hard specular dot (PSX style — always top-right)
            draw.ellipse([cx+2, cy-ri+1, cx+6, cy-ri+5], fill=p["spec"])
            draw.ellipse([cx+3, cy-ri+2, cx+5, cy-ri+4], fill=(255,255,255,255))

        if angry:
            sign = -1 if cx < 75 else 1
            draw.line([cx-sign*ro, cy-ro-3, cx+sign*ro, cy-ro+3],
                      fill=p["outline"], width=3)
            draw.line([cx-sign*(ro-1), cy-ro-2, cx+sign*(ro-1), cy-ro+2],
                      fill=p["mouth"], width=2)


# ---------------------------------------------------------------------------
# Tentacles — segmented cylinders, flat shaded (PSX style)
# ---------------------------------------------------------------------------

def _tentacle_segments(bx, by, ex, ey, n=4):
    """Return n+1 points along a slightly curved tentacle path."""
    pts = []
    for i in range(n+1):
        t = i / n
        x = bx + (ex-bx)*t + math.sin(t*math.pi)*8*(1 if bx<75 else -1)
        y = by + (ey-by)*t
        pts.append((int(x), int(y)))
    return pts


TENT_SPECS = [
    (-38, 10,  -62, 75),
    (-22, 12,  -38, 80),
    (- 8, 14,  -10, 82),
    (  8, 14,   14, 82),
    ( 22, 12,   40, 80),
    ( 38, 10,   64, 75),
    (-28, 10,  -78, 58),
    ( 28, 10,   80, 58),
]


def _draw_tentacles(draw: ImageDraw.ImageDraw, p: dict, yo: int):
    base_cy = 72 + 42 - 6 + yo   # bottom of mantle
    for (oxb, _, oxe, dye) in TENT_SPECS:
        bx = 75 + oxb
        by = base_cy
        ex = 75 + oxe
        ey = base_cy + dye
        pts = _tentacle_segments(bx, by, ex, ey, n=5)
        for i in range(len(pts)-1):
            progress = i / (len(pts)-1)
            w = max(2, int(6 * (1-progress)))
            # Flat shade: lit side vs shadow side
            draw.line([pts[i], pts[i+1]], fill=p["tent"], width=w+2)
            draw.line([pts[i], pts[i+1]], fill=p["tent_d"], width=max(1,w-1))
            # Sucker dot
            sx, sy = pts[i]
            if i % 2 == 1:
                draw.ellipse([sx-2, sy-2, sx+2, sy+2], fill=p["dark"])
        # Tip
        tx, ty = pts[-1]
        draw.ellipse([tx-2, ty-2, tx+2, ty+2], fill=p["tent_d"])


# ---------------------------------------------------------------------------
# Mouth
# ---------------------------------------------------------------------------

def _draw_mouth(draw: ImageDraw.ImageDraw, p: dict, yo: int, style: str):
    mx, my = 75, 72 + 20 + yo
    if style == "smile":
        draw.arc([mx-18, my-10, mx+18, my+10], 15, 165, fill=p["outline"], width=3)
        draw.arc([mx-16, my-8,  mx+16, my+8],  20, 160, fill=p["mouth"],   width=2)
    elif style == "sad":
        draw.arc([mx-16, my-4, mx+16, my+12], 200, 340, fill=p["outline"], width=3)
        draw.arc([mx-14, my-2, mx+14, my+10], 205, 335, fill=p["mouth"],   width=2)
    elif style == "flat":
        draw.line([mx-14, my+2, mx+14, my+2], fill=p["outline"], width=3)
        draw.line([mx-13, my+2, mx+13, my+2], fill=p["mouth"],   width=2)
    elif style == "wide":
        draw.arc([mx-24, my-14, mx+24, my+14], 8,  172, fill=p["outline"], width=3)
        draw.arc([mx-22, my-12, mx+22, my+12], 10, 170, fill=p["mouth"],   width=2)
        # Teeth suggestion (PSX style — just two rectangles)
        for tx in [mx-8, mx+2]:
            draw.rectangle([tx, my-4, tx+6, my+2], fill=p["hi"])
            draw.rectangle([tx, my-4, tx+6, my+2], outline=p["outline"])


# ---------------------------------------------------------------------------
# Pixelation pass — the key PSX trick
# ---------------------------------------------------------------------------

def _pixelate(img: Image.Image, factor: int = 3) -> Image.Image:
    """Downscale with NEAREST then upscale back — gives chunky pixel look."""
    small = img.resize((W // factor, H // factor), Image.NEAREST)
    return small.resize((W, H), Image.NEAREST)


# ---------------------------------------------------------------------------
# Scanline / noise pass
# ---------------------------------------------------------------------------

def _add_scanlines(img: Image.Image, strength: int = 18) -> Image.Image:
    """Subtle horizontal dark lines every 2px for CRT/TV monitor feel."""
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw    = ImageDraw.Draw(overlay)
    for y in range(0, H, 2):
        draw.line([(0, y), (W-1, y)], fill=(0, 0, 0, strength))
    return Image.alpha_composite(img, overlay)


# ---------------------------------------------------------------------------
# Glitch overlay
# ---------------------------------------------------------------------------

def make_glitch(intensity: float = 0.5) -> Image.Image:
    img  = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Horizontal scan-tear lines (PSX disc-read error style)
    for _ in range(int(12 * intensity)):
        y  = random.randint(0, H-1)
        w  = random.randint(20, W-10)
        x  = random.randint(0, W-w)
        c  = random.choice([(180,0,180),(100,0,200),(200,200,255),(255,100,180)])
        draw.rectangle([x, y, x+w, y+random.randint(1,4)],
                       fill=(*c, random.randint(100,220)))
    # Random pixel noise
    px = img.load()
    for _ in range(int(200 * intensity)):
        x, y = random.randint(0,W-1), random.randint(0,H-1)
        c = random.choice([(255,255,255,200),(180,0,220,200),(0,0,0,180)])
        px[x, y] = c
    return img


# ---------------------------------------------------------------------------
# Frame builder
# ---------------------------------------------------------------------------

def make_frame(state: str, idx: int) -> Image.Image:
    p   = PAL[state]
    yo  = BOB[idx]

    # Work on a 2x canvas for quality, then pixelate down
    img  = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    _draw_tentacles(draw, p, yo)
    _draw_mantle(img, draw, p, yo)
    _draw_mouth(draw, p, yo,
                {"happy":"smile","lonely":"sad",
                 "angry":"flat","manipulative":"wide"}[state])
    _draw_eyes(draw, img, p, yo,
               blink=(idx == 3),
               wide=(state == "manipulative"),
               angry=(state == "angry"))

    # PSX pixelation — factor 2 keeps it readable but crunchy
    img = _pixelate(img, factor=2)

    return img


# ---------------------------------------------------------------------------
# Generate all
# ---------------------------------------------------------------------------

def generate_all(output_dir: Path = SPRITES_DIR) -> None:
    print(f"Generating PSX-style MOMO sprites → {output_dir}")
    for state in ("happy", "lonely", "angry", "manipulative"):
        d = output_dir / state
        d.mkdir(parents=True, exist_ok=True)
        for i in range(FRAMES):
            make_frame(state, i).save(str(d / f"frame_{i}.png"))
        print(f"  ✓ {state}")

    gd = output_dir / "glitch"
    gd.mkdir(parents=True, exist_ok=True)
    for i in range(FRAMES):
        make_glitch(0.3 + i * 0.2).save(str(gd / f"frame_{i}.png"))
    print("  ✓ glitch\nDone.")


if __name__ == "__main__":
    generate_all()
