"""
utils/helpers.py
----------------
Miscellaneous utility functions shared across modules.
"""

import re
import time
from datetime import datetime
from typing import Optional


def extract_name_from_text(text: str) -> Optional[str]:
    """
    Attempt to parse the user's name from a self-introduction.
    Handles common patterns: "I'm Leon", "my name is Leon", "call me Leon".

    Returns the name string or None if not found.
    """
    patterns = [
        r"(?:i'm|i am|im)\s+([A-Z][a-z]+)",
        r"(?:my name is|my name's)\s+([A-Z][a-z]+)",
        r"(?:call me|they call me)\s+([A-Z][a-z]+)",
        r"(?:this is|it's)\s+([A-Z][a-z]+)\s+(?:here|speaking)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            name = match.group(1).strip()
            # Basic sanity check - skip common false positives
            skip = {"fine", "good", "ok", "okay", "here", "back", "there", "done"}
            if name.lower() not in skip and len(name) > 1:
                return name.capitalize()
    return None


def seconds_since(timestamp: float) -> float:
    """Return seconds elapsed since a Unix timestamp."""
    return time.time() - timestamp


def friendly_elapsed(seconds: float) -> str:
    """
    Return a human-readable elapsed time string.
    Used by the companion when referencing your absence.
    """
    if seconds < 60:
        return f"{int(seconds)} seconds"
    if seconds < 3600:
        mins = int(seconds / 60)
        return f"{mins} minute{'s' if mins != 1 else ''}"
    if seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''}"
    days = int(seconds / 86400)
    return f"{days} day{'s' if days != 1 else ''}"


def time_of_day_label() -> str:
    """Return 'morning', 'afternoon', 'evening', or 'night'."""
    hour = datetime.now().hour
    if 5 <= hour < 12:
        return "morning"
    if 12 <= hour < 17:
        return "afternoon"
    if 17 <= hour < 21:
        return "evening"
    return "night"


def corrupt_text(text: str, intensity: float = 0.08) -> str:
    """
    Introduce random character corruption into a string.
    Used for glitched dialogue lines. Intensity is 0.0–1.0.
    """
    import random
    glitch_chars = "▓▒░█▄▀■□▪▫◆◇●○◉◎⬛⬜"
    result = []
    for char in text:
        if char != " " and random.random() < intensity:
            result.append(random.choice(glitch_chars))
        else:
            result.append(char)
    return "".join(result)


def clamp(value: float, min_val: float, max_val: float) -> float:
    """Standard numeric clamp."""
    return max(min_val, min(max_val, value))
