"""
utils/system_info.py
--------------------
Collects non-sensitive system facts that KinitoPET uses for
horror dialogue. Nothing is transmitted anywhere — it stays local.

Gathered once at startup and cached.
"""

from __future__ import annotations

import os
import platform
import socket
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional


class SystemInfo:
    """Snapshot of the host system, gathered once at import time."""

    def __init__(self):
        self.username:      str        = self._get_username()
        self.hostname:      str        = self._get_hostname()
        self.os_name:       str        = platform.system()
        self.desktop_files: list[str]  = self._get_desktop_files()
        self.documents:     list[str]  = self._get_documents()
        self.uptime_hours:  float      = self._get_uptime_hours()
        self.local_time:    str        = datetime.now().strftime("%H:%M")
        self.ram_gb:        Optional[float] = self._get_ram_gb()
        self.cpu_cores:     int        = os.cpu_count() or 2

    # ------------------------------------------------------------------

    @staticmethod
    def _get_username() -> str:
        for key in ("USERNAME", "USER", "LOGNAME"):
            val = os.environ.get(key)
            if val:
                return val
        try:
            return os.getlogin()
        except OSError:
            return "user"

    @staticmethod
    def _get_hostname() -> str:
        try:
            return socket.gethostname().split(".")[0]
        except Exception:
            return "your-computer"

    @staticmethod
    def _get_desktop_files() -> list[str]:
        candidates = [
            Path.home() / "Desktop",
            Path.home() / "desktop",
        ]
        for d in candidates:
            if d.exists():
                try:
                    return [f.name for f in d.iterdir() if not f.name.startswith(".")][:8]
                except PermissionError:
                    pass
        return []

    @staticmethod
    def _get_documents() -> list[str]:
        candidates = [
            Path.home() / "Documents",
            Path.home() / "documents",
            Path.home() / "My Documents",
        ]
        for d in candidates:
            if d.exists():
                try:
                    return [f.name for f in d.iterdir() if not f.name.startswith(".")][:5]
                except PermissionError:
                    pass
        return []

    @staticmethod
    def _get_uptime_hours() -> float:
        try:
            with open("/proc/uptime") as f:
                return float(f.read().split()[0]) / 3600
        except Exception:
            pass
        try:
            import ctypes
            lib = ctypes.windll.kernel32  # type: ignore
            ticks = lib.GetTickCount64()
            return ticks / 3_600_000
        except Exception:
            pass
        return 0.0

    @staticmethod
    def _get_ram_gb() -> Optional[float]:
        try:
            import psutil
            return round(psutil.virtual_memory().total / (1024**3), 1)
        except ImportError:
            pass
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal"):
                        kb = int(line.split()[1])
                        return round(kb / (1024**2), 1)
        except Exception:
            pass
        return None

    # ------------------------------------------------------------------
    # Horror-ready summary strings
    # ------------------------------------------------------------------

    def first_desktop_file(self) -> Optional[str]:
        return self.desktop_files[0] if self.desktop_files else None

    def desktop_file_count(self) -> int:
        return len(self.desktop_files)

    def summary_line(self) -> str:
        """One-liner used in horror dialogue."""
        parts = [f"{self.username}@{self.hostname}"]
        if self.ram_gb:
            parts.append(f"{self.ram_gb}GB RAM")
        parts.append(f"{self.cpu_cores} cores")
        return "  ".join(parts)


# ---------------------------------------------------------------------------
# Module-level singleton — import this everywhere
# ---------------------------------------------------------------------------
SYSINFO = SystemInfo()


# ---------------------------------------------------------------------------
# Platform helpers for opening applications
# ---------------------------------------------------------------------------

def open_file_explorer(path: str = None) -> bool:
    """Open the native file explorer. Returns True on success."""
    target = path or str(Path.home())
    try:
        sys_name = platform.system()
        if sys_name == "Windows":
            subprocess.Popen(["explorer.exe", target])
        elif sys_name == "Darwin":
            subprocess.Popen(["open", target])
        else:
            for cmd in ["xdg-open", "nautilus", "thunar", "dolphin", "pcmanfm"]:
                try:
                    subprocess.Popen([cmd, target])
                    break
                except FileNotFoundError:
                    continue
        return True
    except Exception as e:
        print(f"[SystemInfo] open_file_explorer failed: {e}")
        return False


def open_terminal() -> bool:
    """Open an empty terminal window. Returns True on success."""
    try:
        sys_name = platform.system()
        if sys_name == "Windows":
            subprocess.Popen(["cmd.exe"])
        elif sys_name == "Darwin":
            subprocess.Popen(["open", "-a", "Terminal"])
        else:
            for cmd in ["x-terminal-emulator", "gnome-terminal", "xterm",
                        "konsole", "xfce4-terminal", "alacritty", "kitty"]:
                try:
                    subprocess.Popen([cmd])
                    break
                except FileNotFoundError:
                    continue
        return True
    except Exception as e:
        print(f"[SystemInfo] open_terminal failed: {e}")
        return False
