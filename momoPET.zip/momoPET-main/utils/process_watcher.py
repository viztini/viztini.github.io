"""
utils/process_watcher.py
------------------------
Reads the running process list for MOMO's commentary.
Read-only. No interference with any process.
"""
from __future__ import annotations
import platform, subprocess
from functools import lru_cache

_OS = platform.system()

def get_running_apps() -> list[str]:
    try:
        if _OS == "Windows":
            out = subprocess.check_output(
                ["tasklist", "/FI", "STATUS eq RUNNING"],
                timeout=4, stderr=subprocess.DEVNULL
            ).decode("utf-8", "ignore")
            return [ln.split()[0].lower() for ln in out.splitlines() if ln.split()]
        else:
            out = subprocess.check_output(
                ["ps", "-e", "-o", "comm"], timeout=4, stderr=subprocess.DEVNULL
            ).decode("utf-8", "ignore")
            return [ln.strip().lower() for ln in out.splitlines()]
    except Exception:
        return []

def is_streaming() -> bool:
    apps = get_running_apps()
    return any(a in apps for a in ["obs64.exe","obs32.exe","obs","obs-studio"])

def is_discord_open() -> bool:
    apps = get_running_apps()
    return any(a in apps for a in ["discord.exe","discord","discordptb.exe"])

def get_notable_apps() -> list[str]:
    apps = set(get_running_apps())
    checks = {
        "Spotify":       ["spotify.exe","spotify"],
        "Discord":       ["discord.exe","discord","discordptb.exe"],
        "Steam":         ["steam.exe","steam"],
        "VS Code":       ["code.exe","code"],
        "Chrome":        ["chrome.exe","chromium","chromium-browser"],
        "Firefox":       ["firefox.exe","firefox"],
        "Brave":         ["brave.exe","brave"],
        "OBS":           ["obs64.exe","obs32.exe","obs"],
        "Blender":       ["blender.exe","blender"],
        "Photoshop":     ["photoshop.exe"],
    }
    found = []
    for name, procs in checks.items():
        if any(p in apps for p in procs):
            found.append(name)
    return found
