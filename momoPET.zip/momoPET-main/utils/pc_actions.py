"""
utils/pc_actions.py — Safe, non-destructive PC interactions.
speak_text fixed: uses VBScript on Windows (reliable spaces), say on Mac, espeak on Linux.
"""
from __future__ import annotations
import os, platform, subprocess, tempfile
from pathlib import Path
from typing import Optional

_OS = platform.system()

def open_calculator() -> bool:
    try:
        if _OS == "Windows":   subprocess.Popen(["calc.exe"])
        elif _OS == "Darwin":  subprocess.Popen(["open", "-a", "Calculator"])
        else:
            for c in ["gnome-calculator","kcalc","xcalc","qalculate-gtk"]:
                try: subprocess.Popen([c]); break
                except FileNotFoundError: continue
        return True
    except Exception: return False

def open_notepad(text: str = "") -> bool:
    try:
        path = None
        if text:
            tmp = tempfile.NamedTemporaryFile(
                mode="w", suffix=".txt", delete=False, encoding="utf-8")
            tmp.write(text); tmp.close(); path = tmp.name
        if _OS == "Windows":
            subprocess.Popen(["notepad.exe"] + ([path] if path else []))
        elif _OS == "Darwin":
            subprocess.Popen(["open", "-a", "TextEdit"] + ([path] if path else []))
        else:
            for e in ["gedit","mousepad","kate","xfce4-terminal","nano"]:
                try: subprocess.Popen([e] + ([path] if path else [])); break
                except FileNotFoundError: continue
        return True
    except Exception: return False

def open_browser(url: str = "https://www.google.com") -> bool:
    try:
        import webbrowser; webbrowser.open(url); return True
    except Exception: return False

def speak_text(text: str, voice_index: int = 0, pitch: int = 140, speed: int = 157) -> bool:
    """
    Fixed: Windows now uses VBScript (SAPI.SpVoice) which handles
    spaces and punctuation correctly. No more word-joining bug.
    
    Args:
        text: The text to speak
        voice_index: Index of the voice to use (default 0 is system default)
        pitch: Pitch level (0-255, typical range 50-200, default 140)
        speed: Speech rate/speed (typical range 50-200, default 157)
    """
    # Strip markdown asterisks so *text* doesn't get spoken literally
    clean = text.replace("*", "").replace("_", "").strip()
    if not clean:
        return False
    try:
        if _OS == "Windows":
            # VBScript approach, most reliable on all Windows versions
            safe = clean.replace('"', "'").replace("\n", " ")
            # Normalize pitch and speed to SAPI rate scale (-10 to 10 becomes 0-255 scale)
            # speed maps to Rate property, pitch affects voice selection
            vbs  = f"""Set objVoice = CreateObject("SAPI.SpVoice")
Set objVoices = objVoice.GetVoices()
If objVoices.Count > {voice_index} Then
    Set objVoice.Voice = objVoices.Item({voice_index})
End If
objVoice.Rate = ({speed} - 157) / 10
objVoice.Speak "{safe}" """
            tmp  = tempfile.NamedTemporaryFile(
                mode="w", suffix=".vbs", delete=False, encoding="utf-8")
            tmp.write(vbs); tmp.close()
            subprocess.Popen(
                ["cscript", "//nologo", tmp.name],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        elif _OS == "Darwin":
            subprocess.Popen(["say", clean])
        else:
            safe = clean.replace('"', "'")
            for cmd in [["espeak", safe], ["espeak-ng", safe],
                        ["festival", "--tts"]]:
                try: subprocess.Popen(cmd); break
                except FileNotFoundError: continue
        return True
    except Exception: return False

def get_clipboard_text() -> Optional[str]:
    try:
        if _OS == "Windows":
            r = subprocess.run(["powershell","-Command","Get-Clipboard"],
                               capture_output=True, text=True, timeout=3)
            return r.stdout.strip() or None
        elif _OS == "Darwin":
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
            return r.stdout.strip() or None
        else:
            for cmd in [["xclip","-o"],["xsel","--output"]]:
                try:
                    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
                    return r.stdout.strip() or None
                except FileNotFoundError: continue
    except Exception: pass
    return None

def list_tts_voices() -> list[tuple[int, str]]:
    """
    List all available TTS voices on Windows.
    Returns: [(index, voice_name), ...]
    """
    if _OS != "Windows":
        return []
    try:
        vbs = """Set objVoice = CreateObject("SAPI.SpVoice")
Set objVoices = objVoice.GetVoices()
For i = 0 To objVoices.Count - 1
    WScript.Echo i & "|" & objVoices.Item(i).GetAttribute("Name")
Next"""
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".vbs", delete=False, encoding="utf-8")
        tmp.write(vbs); tmp.close()
        result = subprocess.run(
            ["cscript", "//nologo", tmp.name],
            capture_output=True, text=True, timeout=5)
        voices = []
        for line in result.stdout.strip().split("\n"):
            if "|" in line:
                idx, name = line.split("|", 1)
                voices.append((int(idx), name))
        return voices
    except Exception:
        return []


def drop_desktop_file(filename: str, content: str) -> bool:
    """Write a single small text file to the user's desktop."""
    try:
        desktop = Path.home() / "Desktop"
        if not desktop.exists():
            desktop = Path.home() / "desktop"
        if not desktop.exists():
            return False
        path = desktop / filename
        path.write_text(content, encoding="utf-8")
        return True
    except Exception: return False
