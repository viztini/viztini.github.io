"""
memory/database.py
------------------
Thin SQLite wrapper.  All raw SQL lives here so the rest of
the codebase never touches sqlite3 directly.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator


_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at  REAL    NOT NULL,
    ended_at    REAL,
    message_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  INTEGER NOT NULL,
    role        TEXT    NOT NULL,   -- 'user' | 'assistant'
    content     TEXT    NOT NULL,
    timestamp   REAL    NOT NULL,
    state       TEXT,               -- PersonalityState.value at time of message
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS companion_kv (
    key         TEXT    PRIMARY KEY,
    value       TEXT    NOT NULL,
    updated_at  REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS horror_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type  TEXT    NOT NULL,
    fired_at    REAL    NOT NULL,
    session_id  INTEGER
);

CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id);
CREATE INDEX IF NOT EXISTS idx_messages_ts      ON messages(timestamp);
"""


class Database:
    """Low-level database access.  Use MemoryManager for higher-level ops."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._bootstrap()

    # ------------------------------------------------------------------
    # Connection context manager
    # ------------------------------------------------------------------

    @contextmanager
    def conn(self) -> Generator[sqlite3.Connection, None, None]:
        connection = sqlite3.connect(str(self.db_path))
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    # ------------------------------------------------------------------
    # Schema bootstrap
    # ------------------------------------------------------------------

    def _bootstrap(self) -> None:
        with self.conn() as c:
            c.executescript(_SCHEMA)

    # ------------------------------------------------------------------
    # Generic helpers
    # ------------------------------------------------------------------

    def execute(self, sql: str, params: tuple = ()) -> None:
        with self.conn() as c:
            c.execute(sql, params)

    def fetchone(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        with self.conn() as c:
            return c.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        with self.conn() as c:
            return c.execute(sql, params).fetchall()

    def insert(self, sql: str, params: tuple = ()) -> int:
        """Execute an INSERT and return the last row id."""
        with self.conn() as c:
            cur = c.execute(sql, params)
            return cur.lastrowid

    # ------------------------------------------------------------------
    # Key/value store (companion_kv)
    # ------------------------------------------------------------------

    def kv_set(self, key: str, value: str) -> None:
        import time
        self.execute(
            "INSERT INTO companion_kv(key, value, updated_at) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key, value, time.time()),
        )

    def kv_get(self, key: str, default: str | None = None) -> str | None:
        row = self.fetchone("SELECT value FROM companion_kv WHERE key=?", (key,))
        return row["value"] if row else default

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def create_session(self, started_at: float) -> int:
        return self.insert(
            "INSERT INTO sessions(started_at) VALUES(?)", (started_at,)
        )

    def close_session(self, session_id: int, ended_at: float, message_count: int) -> None:
        self.execute(
            "UPDATE sessions SET ended_at=?, message_count=? WHERE id=?",
            (ended_at, message_count, session_id),
        )

    # ------------------------------------------------------------------
    # Messages
    # ------------------------------------------------------------------

    def save_message(
        self,
        session_id: int,
        role: str,
        content: str,
        timestamp: float,
        state: str,
    ) -> int:
        return self.insert(
            "INSERT INTO messages(session_id, role, content, timestamp, state) "
            "VALUES(?,?,?,?,?)",
            (session_id, role, content, timestamp, state),
        )

    def get_recent_messages(self, limit: int = 20) -> list[dict[str, Any]]:
        rows = self.fetchall(
            "SELECT role, content, state FROM messages "
            "ORDER BY timestamp DESC LIMIT ?",
            (limit,),
        )
        # Return in chronological order
        return [dict(r) for r in reversed(rows)]

    def get_message_count(self) -> int:
        row = self.fetchone("SELECT COUNT(*) as c FROM messages WHERE role='user'")
        return row["c"] if row else 0

    def get_session_count(self) -> int:
        row = self.fetchone("SELECT COUNT(*) as c FROM sessions")
        return row["c"] if row else 0

    # ------------------------------------------------------------------
    # Horror log
    # ------------------------------------------------------------------

    def log_horror_event(self, event_type: str, fired_at: float, session_id: int) -> None:
        self.execute(
            "INSERT INTO horror_log(event_type, fired_at, session_id) VALUES(?,?,?)",
            (event_type, fired_at, session_id),
        )

    def get_last_horror_time(self) -> float:
        row = self.fetchone("SELECT MAX(fired_at) as t FROM horror_log")
        return row["t"] or 0.0

    def get_horror_event_count(self, event_type: str) -> int:
        row = self.fetchone(
            "SELECT COUNT(*) as c FROM horror_log WHERE event_type=?", (event_type,)
        )
        return row["c"] if row else 0
