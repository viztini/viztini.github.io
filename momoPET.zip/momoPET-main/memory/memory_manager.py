"""
memory/memory_manager.py
------------------------
High-level memory operations.  This is what the rest of the
application talks to — never the raw Database directly.

Responsibilities
----------------
- Track the current session (start / end / message count)
- Persist and restore StateContext across runs
- Build the conversation context window for the AI
- Store and retrieve the companion's KV state (name, familiarity, etc.)
"""

from __future__ import annotations

import json
import time
from typing import Any

import config
from core.state_machine import PersonalityState, StateContext
from memory.database import Database


class MemoryManager:
    """Stateful manager bound to a single Database."""

    def __init__(self, db: Database):
        self._db         = db
        self._session_id = self._db.create_session(time.time())
        self._msg_count  = 0      # messages this session

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    @property
    def session_id(self) -> int:
        return self._session_id

    def end_session(self) -> None:
        self._db.close_session(self._session_id, time.time(), self._msg_count)

    # ------------------------------------------------------------------
    # Message persistence
    # ------------------------------------------------------------------

    def save_user_message(self, content: str, state: PersonalityState) -> None:
        self._db.save_message(
            self._session_id, "user", content, time.time(), state.value
        )
        self._msg_count += 1

    def save_assistant_message(self, content: str, state: PersonalityState) -> None:
        self._db.save_message(
            self._session_id, "assistant", content, time.time(), state.value
        )
        self._msg_count += 1

    def get_context_window(self) -> list[dict[str, str]]:
        """
        Return the last N messages formatted for the Anthropic messages API.
        [{"role": "user"|"assistant", "content": "..."}]
        """
        rows = self._db.get_recent_messages(config.MAX_CONTEXT_MESSAGES)
        return [{"role": r["role"], "content": r["content"]} for r in rows]

    # ------------------------------------------------------------------
    # State persistence (companion_kv)
    # ------------------------------------------------------------------

    def save_state_context(self, ctx: StateContext) -> None:
        """Serialise the StateContext into the KV store."""
        data = {
            "current_state":             ctx.current_state.value,
            "last_interaction_ts":       ctx.last_interaction_ts,
            "session_count":             ctx.session_count,
            "total_messages":            ctx.total_messages,
            "close_without_chat_count":  ctx.close_without_chat_count,
            "consecutive_ignored":       ctx.consecutive_ignored,
            "familiarity_level":         ctx.familiarity_level,
            "user_name":                 ctx.user_name,
        }
        self._db.kv_set("state_context", json.dumps(data))

    def load_state_context(self) -> StateContext:
        """Restore StateContext from KV store, or return a fresh one."""
        raw = self._db.kv_get("state_context")
        if not raw:
            ctx = StateContext()
            # Hydrate session/message counts from DB for accuracy
            ctx.session_count    = self._db.get_session_count()
            ctx.total_messages   = self._db.get_message_count()
            return ctx

        data = json.loads(raw)
        ctx = StateContext(
            current_state            = PersonalityState(data.get("current_state", "happy")),
            last_interaction_ts      = data.get("last_interaction_ts", time.time()),
            session_count            = data.get("session_count", 0),
            total_messages           = data.get("total_messages", 0),
            close_without_chat_count = data.get("close_without_chat_count", 0),
            consecutive_ignored      = data.get("consecutive_ignored", 0),
            familiarity_level        = data.get("familiarity_level", 0),
            user_name                = data.get("user_name"),
        )
        # Always sync counts from DB to catch discrepancies
        ctx.session_count  = self._db.get_session_count()
        ctx.total_messages = self._db.get_message_count()
        return ctx

    # ------------------------------------------------------------------
    # User metadata
    # ------------------------------------------------------------------

    def get_user_name(self) -> str | None:
        ctx_raw = self._db.kv_get("state_context")
        if ctx_raw:
            return json.loads(ctx_raw).get("user_name")
        return None

    def set_user_name(self, name: str) -> None:
        # Update inside the full context blob
        ctx_raw = self._db.kv_get("state_context")
        if ctx_raw:
            data = json.loads(ctx_raw)
            data["user_name"] = name
            self._db.kv_set("state_context", json.dumps(data))
        else:
            self._db.kv_set("user_name", name)

    # ------------------------------------------------------------------
    # Horror log
    # ------------------------------------------------------------------

    def log_horror(self, event_type: str) -> None:
        self._db.log_horror_event(event_type, time.time(), self._session_id)

    def seconds_since_last_horror(self) -> float:
        last = self._db.get_last_horror_time()
        return time.time() - last if last else float("inf")

    def horror_event_count(self, event_type: str) -> int:
        return self._db.get_horror_event_count(event_type)

    # ------------------------------------------------------------------
    # Aggregate stats (used by dialogue system)
    # ------------------------------------------------------------------

    def get_stats(self) -> dict[str, Any]:
        return {
            "session_count":  self._db.get_session_count(),
            "total_messages": self._db.get_message_count(),
        }
