#!/usr/bin/env python3
"""
List all available TTS voices on your system and test them.
Usage: python list_voices.py
"""
import sys
import config
from utils.pc_actions import list_tts_voices, speak_text

if __name__ == "__main__":
    voices = list_tts_voices()
    
    if not voices:
        print("No voices found. Are you on Windows?")
        sys.exit(1)
    
    print(f"Found {len(voices)} voice(s):\n")
    for idx, name in voices:
        print(f"  [{idx}] {name}")
    
    print("\n" + "="*60)
    print("To use a voice, set TTS_VOICE_INDEX in config.py")
    print("Example: TTS_VOICE_INDEX = 1")
    print("="*60 + "\n")
    
    # Get settings from config
    pitch = getattr(config, 'TTS_VOICE_PITCH', 140)
    speed = getattr(config, 'TTS_VOICE_SPEED', 157)
    print(f"Current settings: pitch={pitch}, speed={speed}\n")
    
    # Test each voice
    test_text = "Hello, I am momoPET!"
    for idx, name in voices:
        print(f"Testing voice {idx} ({name})...")
        speak_text(test_text, voice_index=idx, pitch=pitch, speed=speed)
        input("Press Enter to test next voice...")
