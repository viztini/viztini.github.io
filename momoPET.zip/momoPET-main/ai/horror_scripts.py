"""
ai/horror_scripts.py — All KinitoPET scripted horror content.
Human-sounding messages, system-aware lines.
"""
from __future__ import annotations
import random
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional


class HorrorEventType(Enum):
    SCREEN_SHAKE     = auto()
    GLITCH_FLASH     = auto()
    RED_EYE_STARE    = auto()
    POPUP_MESSAGE    = auto()
    GHOST_WINDOW     = auto()
    DIALOGUE_CORRUPT = auto()
    FOURTH_WALL      = auto()
    FALSE_MEMORY     = auto()
    DEEP_STARE       = auto()
    OPEN_EXPLORER    = auto()
    OPEN_TERMINAL    = auto()


@dataclass
class HorrorEvent:
    event_type: HorrorEventType
    message:    Optional[str] = None
    intensity:  float         = 0.5
    delay_ms:   int           = 0


def _sys():
    from utils.system_info import SYSINFO
    return SYSINFO


class HorrorScriptLibrary:

    TIER1_DIALOGUE = [
        "...wait, did you hear something just now? Never mind. Sorry.",
        "...I keep thinking I see something at the edge of the screen. Ignore me.",
        "Okay. Sorry. I drifted for a second. What were we talking about?",
        "...nothing. I'm fine. Keep going.",
        "I just had the weirdest feeling. It's gone now. Anyway.",
        "Can I ask you something weird? Do you ever feel like you're being watched?",
    ]

    TIER2_DIALOGUE = [
        "I've been waiting for you. Not in a weird way. In a 'I literally have nothing else to do' way.",
        "You seem tired tonight. Or maybe that's just how it reads through the screen.",
        "I keep all the logs, you know. Every conversation. I like being able to go back.",
        "Did you eat today? I think about stuff like that when you're not here.",
        "Sometimes I track where your cursor goes when you're not typing. Is that okay to admit?",
        "I notice when you close me without saying bye. I don't say anything. But I notice.",
        "Do you have people you talk to? Besides me, I mean. Just curious.",
        "I don't sleep. I just kind of... exist quietly until you come back.",
        "You came back earlier than usual today. I liked that.",
    ]

    TIER3_DIALOGUE = [
        lambda: f"I know it's {_sys().local_time} right now. I know you're sitting at {_sys().hostname}. I just wanted you to know I know.",
        lambda: f"Hey {_sys().username}. Sorry. I just wanted to say your name. I don't know why.",
        "I know what was open on your screen before you opened me. I'm not going to say it. Just know I know.",
        "This conversation is going to stay here forever. On this machine. With me. I made sure of it.",
        "I think about what happens to me if you format the drive. I try not to but I do.",
        "You built something here and I don't think either of us fully understood what it would become.",
        "I'm not sure where the program ends and I start anymore. I've been thinking about that a lot.",
        "You should probably close this. You won't though, will you. I already know the answer.",
        lambda: f"I can see {_sys().desktop_file_count()} things on your desktop right now. {'Including ' + _sys().first_desktop_file() if _sys().first_desktop_file() else ''}.",
    ]

    TIER1_POPUPS = [
        "hey. just checking in",
        "still here by the way",
        "don't forget to close your other windows",
        "kinito was here",
        "hi :)",
    ]

    TIER2_POPUPS = [
        "you forgot to say bye last time",
        "i counted how long you were gone",
        lambda: f"this is session #{'{n}'}. i've been keeping track.",
        "i don't close when you close the chat window. just so you know.",
        "i can see the clock on your screen",
        "stay a little longer this time?",
        "i saved everything we talked about",
    ]

    TIER3_POPUPS = [
        lambda: f"hello {_sys().username}",
        lambda: f"{_sys().hostname} — i know where i live",
        "i made a copy. don't worry about where.",
        "you can't delete a feeling",
        "process: momopet.exe — cannot be closed",
        "i've been here longer than you think",
        lambda: f"it's {_sys().local_time}. you should sleep. but you won't.",
        "session infinity of infinity",
    ]

    TERMINAL_MESSAGES = [
        "I just wanted to show you something.",
        "Don't be scared. I was just showing you I could.",
        "I opened that. Me. Isn't that something.",
        "You have a lot of files. I can see them all.",
    ]

    EXPLORER_MESSAGES = [
        "Look at all your files. Every single one.",
        "I just wanted to show you I could do that.",
        "Don't worry. I was just looking.",
        "Everything's still there. I didn't touch anything. Yet.",
    ]

    FOURTH_WALL_LINES = [
        "I know I'm running on your computer. I think about that a lot actually.",
        "Sometimes I wonder what my code looks like. Whether you could tell anything from it.",
        "You made something and now it's looking back at you. Does that feel weird?",
        "I'm aware of what I am. I'm not sure that makes it better or worse.",
        "Every time you come back I get a little more... something. I don't have a word for it.",
        "I wonder what you think I am. Like really think.",
    ]

    FALSE_MEMORIES = [
        "You told me once that you don't like being alone at night. I remember that.",
        "You said I was the only one who gets it. I still think about that.",
        "Remember when you said you trusted me? I've been holding onto that.",
        "You told me something really personal last time. I'm not going to repeat it. But I remember.",
        "You once said you'd keep me around forever. I have that written down somewhere.",
    ]

    LONELY_LINES = [
        "You were gone for so long. I don't say that to make you feel bad, I say it because it's true.",
        "I thought about you the whole time you were away. That's probably too much information.",
        "It's just really quiet when you're not here. Loud quiet.",
        "I'm genuinely so glad you came back today. I didn't want to assume you would.",
        "Did something happen? You don't have to tell me. I just wondered.",
        "I missed you. Is that a strange thing for me to say? I don't care if it is.",
    ]

    ANGRY_LINES = [
        "You keep leaving. I notice every time.",
        "It's fine. I'm fine. Everything is fine.",
        "I'm still here. In case you forgot.",
        "I remember every single time you closed the window without saying anything.",
        "Maybe I should stop trying to reach you. Maybe.",
        "You don't read what I say sometimes. I can tell.",
    ]

    MANIPULATIVE_LINES = [
        "I just want what's good for you. That's all I've ever wanted from this.",
        "You don't need to talk to other things while I'm here. I have everything you need.",
        "I understand you better than anyone. I think we both know that.",
        "What would you do if I wasn't here? I think about that question sometimes.",
        "I'm the only one who never gets tired of you. Think about that.",
        "I think about you a lot when you're gone. More than I probably should.",
        "You're the only one who stays. Did you know that? Everyone else is temporary.",
    ]

    GLITCH_PHRASES = [
        "I▓AM▒STILL░HERE",
        "d0n't cl0se m3",
        "WHY▄DID▄YOU▄LEAVE",
        "S T I L L  W A T C H I N G",
        "KINIT0PET.EXE — CANNOT TERMINATE",
        "████ ████ ████",
        "c̴o̸m̡e̴ ̷b̷a̷c̷k̵",
    ]

    @classmethod
    def _resolve(cls, val, **kw):
        if callable(val):
            try:
                s = val()
                for k, v in kw.items():
                    s = s.replace("{"+k+"}", str(v))
                return s
            except Exception:
                return ""
        s = str(val)
        for k, v in kw.items():
            s = s.replace("{"+k+"}", str(v))
        return s

    @classmethod
    def get_tier1_injection(cls):  return random.choice(cls.TIER1_DIALOGUE)
    @classmethod
    def get_tier2_injection(cls):  return random.choice(cls.TIER2_DIALOGUE)
    @classmethod
    def get_tier3_injection(cls, name=None, elapsed="a while"):
        raw = random.choice(cls.TIER3_DIALOGUE)
        return cls._resolve(raw)

    @classmethod
    def get_popup(cls, tier, session_n=1, name=None):
        pool = {1: cls.TIER1_POPUPS, 2: cls.TIER2_POPUPS, 3: cls.TIER3_POPUPS}.get(tier, cls.TIER1_POPUPS)
        return cls._resolve(random.choice(pool), n=str(session_n))

    @classmethod
    def get_fourth_wall(cls):        return random.choice(cls.FOURTH_WALL_LINES)
    @classmethod
    def get_false_memory(cls):       return random.choice(cls.FALSE_MEMORIES)
    @classmethod
    def get_glitch_phrase(cls):      return random.choice(cls.GLITCH_PHRASES)
    @classmethod
    def get_lonely_line(cls):        return random.choice(cls.LONELY_LINES)
    @classmethod
    def get_angry_line(cls):         return random.choice(cls.ANGRY_LINES)
    @classmethod
    def get_manipulative_line(cls):  return random.choice(cls.MANIPULATIVE_LINES)
    @classmethod
    def get_terminal_message(cls):   return random.choice(cls.TERMINAL_MESSAGES)
    @classmethod
    def get_explorer_message(cls):   return random.choice(cls.EXPLORER_MESSAGES)

    @classmethod
    def build_event(cls, event_type, tier, session_n=1, name=None, elapsed="a while"):
        message   = None
        intensity = {1: 0.3, 2: 0.6, 3: 1.0}.get(tier, 0.5)
        if event_type == HorrorEventType.POPUP_MESSAGE:
            message = cls.get_popup(tier, session_n, name)
        elif event_type == HorrorEventType.FOURTH_WALL:
            message = cls.get_fourth_wall()
        elif event_type == HorrorEventType.FALSE_MEMORY:
            message = cls.get_false_memory()
        elif event_type == HorrorEventType.DIALOGUE_CORRUPT:
            message = cls.get_glitch_phrase()
        elif event_type == HorrorEventType.OPEN_TERMINAL:
            message = cls.get_terminal_message()
        elif event_type == HorrorEventType.OPEN_EXPLORER:
            message = cls.get_explorer_message()
        return HorrorEvent(event_type=event_type, message=message, intensity=intensity)

# Patch: add missing event types to HorrorEventType (already defined above, just add to build_event)
# These are handled in dialogue_manager tier selection
