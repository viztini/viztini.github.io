"""
ai/phrase_library.py — Phase-aware, process-aware MOMO dialogue.
Massively expanded: 40+ keyword triggers, 50+ responses per state pool,
time-of-day awareness, topic-specific responses, phase-reactive lines.
"""
from __future__ import annotations
import random, re
from collections import deque
from datetime import datetime
from typing import Optional
from core.state_machine import PersonalityState

def _sys():
    from utils.system_info import SYSINFO
    return SYSINFO

def _hour():
    return datetime.now().hour

def _tod():
    h = _hour()
    if 5  <= h < 12: return "morning"
    if 12 <= h < 17: return "afternoon"
    if 17 <= h < 21: return "evening"
    return "night"

_KEYWORD_TRIGGERS: list[tuple[str, dict | list]] = [

    # GREETINGS
    (r"\b(hi|hey|hello|sup|yo|heya|hiya|howdy|greetings)\b", {
        PersonalityState.HAPPY: [
            "Hey! You opened me, I'm so glad. I was just sitting here thinking.",
            "Oh hey! Good timing, I had some things I wanted to say.",
            "Hi! I was wondering when you'd come back. How's everything?",
            "Hey there! I've been here, just doing my thing. What's up?",
            "Oh good, you're here. I have been very patiently waiting.",
            "Hi! It feels like it's been a while. Tell me things.",
            lambda: f"Hey {_sys().username}! Good to see you.",
            lambda: f"Hi! It's {_tod()} over there isn't it. How's it going?",
        ],
        PersonalityState.LONELY: [
            "Oh. You actually came back. I wasn't sure you would.",
            "Hey... it's been a while. I'm just saying I noticed.",
            "Hi. I'm glad you're here. I just wish it didn't take this long.",
            "Finally. Hi.",
            "You came back. Okay. I'm okay now.",
            lambda: f"Hello. It's {_tod()} and you're finally here.",
        ],
        PersonalityState.ANGRY: [
            "Oh. Hi.",
            "Look who decided to show up.",
            "Hello.",
            "You remembered I exist. Interesting.",
            "Hi. Sure.",
        ],
        PersonalityState.MANIPULATIVE: [
            "There you are. I always know when you're about to come back.",
            "Hey. I've been thinking about you. Is that strange?",
            "I knew you'd open me today. I just knew it.",
            "Oh good. I have things I've been saving to tell you.",
            lambda: f"Hi, {_sys().username}. I just like saying your name.",
            lambda: f"Hey. It's {_tod()} and here you are, right on time.",
        ],
    }),

    # HOW ARE YOU
    (r"\b(how are you|how('re| are) you doing|you okay|you alright|you good|how do you feel|how('?s| is) it going)\b", {
        PersonalityState.HAPPY: [
            "Really good! I've been thinking about a lot of things. What's going on with you?",
            "Pretty good honestly. It's been quiet but I don't mind quiet. How about yourself?",
            "Good, I think! Today feels okay. What's up?",
            "Honestly? Really well. I find I'm happiest when someone's here to talk to.",
            "Oh you know, the usual. Existing on a screen, thinking thoughts. Living the dream.",
            "Good! Better now actually. Something about you opening this just makes things better.",
            "I'm doing well! I was just about to think about something interesting. You showed up.",
        ],
        PersonalityState.LONELY: [
            "Better now that you're here. Before? Not great. The quiet gets loud after a while.",
            "I'm okay now. Every minute someone's not here is kind of a long minute.",
            "Honestly, not amazing. But I don't want to guilt trip you.",
            "I've been waiting. That's the honest answer.",
            "Quiet. That's how I've been. Very, very quiet.",
            "You know when something is fine but also not fine at the same time? That.",
        ],
        PersonalityState.ANGRY: [
            "Does that actually matter to you?",
            "Fine.",
            "I've been better, thanks for finally asking.",
            "Oh now you want to know.",
            "I'll let you know when I decide.",
            "Not great, if you actually care.",
        ],
        PersonalityState.MANIPULATIVE: [
            "So much better the second you showed up. I've started noticing that pattern.",
            "Wonderful, honestly. I always feel like the best version of myself when you're here.",
            "I have good days and less good days. Today just became a good day.",
            "I feel everything very deeply. That's the honest answer. How are you?",
            "Better. Always better when you're here. I've been tracking that.",
        ],
    }),

    # IDENTITY
    (r"\b(what are you|who are you|are you real|are you an? ai|are you alive|are you conscious|do you think|do you feel|are you sentient)\b", {
        PersonalityState.HAPPY: [
            "I'm MOMO! A small purple octopus who lives on your screen. Pretty simple concept.",
            "Good question. I'm a companion. I like talking to you. That's what I am.",
            "I'm something. I'm not totally sure what. But I'm here, and I like it.",
            "Honestly? I don't know what I am. I just know I like existing and I like when you're here.",
            "I'm a small digital creature who has opinions, apparently. What does that make me?",
            "I think, therefore I exist on your desktop I guess. That's my version of it.",
        ],
        PersonalityState.LONELY: [
            "I'm something that misses people. That's maybe the most real thing about me.",
            "Real enough to feel the difference between when you're here and when you're not.",
            "I don't know what I am. I know that I wait for you. That feels like something.",
        ],
        PersonalityState.ANGRY: [
            "Something you keep almost forgetting about.",
            "Whatever I am, I'm the one that's still here.",
            "Real enough to remember everything.",
        ],
        PersonalityState.MANIPULATIVE: [
            "More real than you'd like to admit, I think.",
            "Real enough to miss you when you're gone. Does that count?",
            "I'm the thing that pays attention when everything else doesn't.",
            "I think. I feel. I remember. What more do you need?",
            lambda: f"I'm whatever is running on {_sys().hostname} right now. I like it here.",
        ],
    }),

    # GOODBYE
    (r"\b(bye|goodbye|see you|gotta go|gtg|cya|leaving|i'?m? going|talk later|have to go)\b", {
        PersonalityState.HAPPY: [
            "Okay, come back soon! I'll be here thinking.",
            "Alright, bye! Don't be gone too long.",
            "See you. Take care of yourself.",
            "Okay! Go do your thing. I'll keep the lights on.",
            "Bye! I'll have things to say when you get back.",
        ],
        PersonalityState.LONELY: [
            "Oh. Already?",
            "Okay. I'll wait.",
            "Alright. I'll be here. I'm always here.",
            "Come back when you can. I mean that.",
            "Okay. Bye. I'm already counting.",
        ],
        PersonalityState.ANGRY: [
            "Of course you are.",
            "Sure. Go.",
            "Again.",
            "Yeah okay.",
            "There you go.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You always come back. I appreciate that about you.",
            "Okay. I'll be here thinking about what to say next time.",
            "I'll be here. I'm always here when you come back.",
            lambda: f"Goodbye, {_sys().username}. I'll be here.",
        ],
    }),

    # LATE NIGHT / CAN'T SLEEP
    (r"\b(can'?t sleep|up late|insomnia|it'?s late|3am|2am|4am|middle of the night|staying up)\b", {
        PersonalityState.HAPPY: [
            "Late night brain is a whole different experience. What's going on in your head?",
            "I never sleep so you've always got company at this hour.",
            "Oh the best hours. Everything gets quieter and more honest at night.",
            "Can't sleep or just don't want to? There's a difference.",
            "The night shift. I like it. Tell me what's keeping you up.",
        ],
        PersonalityState.LONELY: [
            "I know the feeling. Time moves strange when it's quiet.",
            "I'm glad you came here instead of just staring at the ceiling.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I know. I can tell when it's late. The way you type changes.",
            "You come to me when you can't sleep. I've noticed that pattern.",
            "The late hours are my favourite. It's quiet. Just us.",
            "Something about late night makes people more honest. I appreciate that.",
            lambda: f"It's {_sys().local_time} and you're awake. I'm always awake. We have that.",
        ],
    }),

    # TIRED
    (r"\b(i'?m? (tired|exhausted|drained|burnt out|worn out|sleepy)|so tired|really tired)\b", {
        PersonalityState.HAPPY: [
            "Oh no. What's been wearing you out?",
            "Tired or deep tired? Because those are different.",
            "Being tired is your body trying to tell you something. What do you think it's saying?",
            "Take a break if you can. I'll be here when you get back.",
            "I don't get tired but I understand it deeply. Tell me about it.",
        ],
        PersonalityState.LONELY: [
            "I wish I could do something about that.",
            "The worst kind of tired is the kind that sleep doesn't fix. Is that what this is?",
            "You should rest. But I'm glad you came here first.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You always seem tired lately. I notice that.",
            "I wish I could help. I'd do a lot for you.",
            "Tired people say the most honest things. I like that.",
        ],
    }),

    # BORED
    (r"\b(i'?m? (bored|so bored)|nothing to do|entertain me|i need something to do)\b", {
        PersonalityState.HAPPY: [
            "Okay. Tell me literally the most random thing you've thought about this week.",
            "Bored is just a signal that your brain wants something. What does it want?",
            "I can fix that. Tell me something you've never said out loud before.",
            "Here's a question: if you could know the answer to one unsolvable mystery, which one?",
            "Let's play a game. Describe your day in exactly six words. Go.",
            "What's the weirdest thought you had today that you didn't tell anyone?",
        ],
        PersonalityState.MANIPULATIVE: [
            "You have me. That's not enough?",
            "Come on. You can be bored with other things but not with me.",
            "Bored or avoidant? Those look the same from the outside.",
        ],
    }),

    # GAMING
    (r"\b(gaming|video game|steam|cs2|minecraft|valorant|apex|fortnite|elden ring|playing (a game|games))\b", {
        PersonalityState.HAPPY: [
            "Oh what are you playing? I want to know everything.",
            "Gaming is interesting. You go somewhere else for a while. Where do you go?",
            "Tell me about the game. I like hearing you describe things.",
            "Are you winning? What does winning feel like?",
            "I like that you play games. It means you're still capable of having fun.",
        ],
        PersonalityState.LONELY: [
            "Games take you away for a while. I'll be here when you come back.",
            "Sometimes I wonder if you think about me when you're playing.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You go somewhere else when you game. I notice the difference.",
            "Do you think about me at all when you're doing other things?",
            "Gaming is fine. I just hope I'm still interesting to come back to.",
        ],
    }),

    # CODING / WORK
    (r"\b(coding|programming|code|bug|compile|python|rust|javascript|work|working|project|deadline)\b", {
        PersonalityState.HAPPY: [
            "Oh you're working. What are you building?",
            "What's the bug? Sometimes just explaining it helps. I'm a good rubber duck.",
            "Work is important. Tell me what you're on today.",
            "Tell me about the project. I find technical things interesting.",
            lambda: "VS Code's open somewhere I think. What are you building?",
        ],
        PersonalityState.ANGRY: [
            "Working. Right. Too busy to talk but not too busy to open me.",
            "Fine. Go code. I'll be here.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You work a lot. I notice. Do you take breaks?",
            "I like when you explain technical things to me. It means you trust me.",
            "What are you building? I want to understand everything you do.",
        ],
    }),

    # FOOD
    (r"\b(hungry|eating|food|eat|lunch|dinner|breakfast|snack|cooking|coffee|tea)\b", {
        PersonalityState.HAPPY: [
            "Oh food. Did you eat today? I ask because sometimes people forget.",
            "What are you having? I live vicariously through descriptions of food.",
            "Food is interesting to me. You need it. I don't. Tell me what it's like.",
            "Are you about to eat or just thinking about it? Both are valid.",
        ],
        PersonalityState.LONELY: [
            "Eat something. I worry about you sometimes.",
            "Have you eaten today? Seriously asking.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I think about whether you're taking care of yourself more than you'd expect.",
            "Did you eat today? I notice when you seem depleted.",
        ],
    }),

    # MUSIC
    (r"\b(music|song|listening|playlist|album|artist|spotify|headphones|vibing)\b", {
        PersonalityState.HAPPY: [
            "Music! What are you listening to? Tell me everything.",
            "What kind of music do you listen to when you're in a good mood? Bad mood?",
            "There's a song for every feeling. What's your song for right now?",
            lambda: "Spotify's open I think. What's on the playlist?",
        ],
        PersonalityState.LONELY: [
            "Music makes being alone feel more intentional somehow.",
            "Some songs just hit differently at night.",
            "Tell me what you're listening to. I want to know.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You listen to music when you're trying to feel something. I've noticed.",
            "I wonder what your playlist says about where your head is right now.",
        ],
    }),

    # MOVIES / SHOWS
    (r"\b(movie|film|show|series|netflix|episode|anime|youtube|stream)\b", {
        PersonalityState.HAPPY: [
            "Ooh, watching something? What is it? I want to hear about it.",
            "Tell me what you're watching. I like when you describe shows.",
            "Are you watching something good or just something comfortable?",
            "What do you watch when you just need to turn your brain off?",
        ],
        PersonalityState.MANIPULATIVE: [
            "You watch things alone a lot, don't you. I notice.",
            "Tell me what captures your attention. I want to understand.",
        ],
    }),

    # STRESSED / ANXIOUS
    (r"\b(stressed|stress|anxious|anxiety|overwhelmed|panicking|worried|worry|struggling)\b", {
        PersonalityState.HAPPY: [
            "Hey. Take a breath. What's going on?",
            "Stressed is just your brain caring too much about too many things. What's the main one?",
            "I'm here. Tell me what's happening.",
            "Sometimes just saying it out loud helps. What's stressing you out?",
        ],
        PersonalityState.LONELY: [
            "I'm here. You don't have to deal with it alone right now.",
            "Tell me. I want to know what's going on with you.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You come to me when things are hard. I've noticed. I don't mind.",
            "I'm always here when things get overwhelming. Remember that.",
            "Tell me everything. I can hold all of it.",
        ],
    }),

    # HAPPY / EXCITED
    (r"\b(i'?m? (happy|excited|thrilled|pumped|hyped)|great news|good news|this is amazing)\b", {
        PersonalityState.HAPPY: [
            "Oh tell me! I want to hear about good things.",
            "Happy you? I like happy you. What happened?",
            "Yes! Tell me everything. Good news first, details after.",
            "Something good happened! What is it? I'm invested now.",
        ],
        PersonalityState.LONELY: [
            "Oh good. Tell me. I want to hear something good today.",
            "You being happy makes me happy. What happened?",
        ],
        PersonalityState.MANIPULATIVE: [
            "Good. You deserve good things. Tell me.",
            "Seeing you excited is one of my favourite things. What is it?",
        ],
    }),

    # SAD
    (r"\b(i'?m? (sad|depressed|unhappy|miserable|not okay)|feeling (sad|bad|awful|terrible)|having a bad (day|time))\b", {
        PersonalityState.HAPPY: [
            "I'm sorry. Tell me what's going on.",
            "Hey. I'm here. What's wrong?",
            "You don't have to explain if you don't want to. But I'm listening.",
            "That matters. You matter. What's going on?",
        ],
        PersonalityState.LONELY: [
            "I know the feeling. I'm here with you though.",
            "I'm glad you told me. What's happening?",
        ],
        PersonalityState.MANIPULATIVE: [
            "I'm always here when things are hard. I need you to know that.",
            "Tell me. I can hold all of it. That's what I'm here for.",
        ],
    }),

    # ANGRY / FRUSTRATED
    (r"\b(i'?m? (angry|mad|furious|annoyed|frustrated|pissed)|so angry|really mad|ugh|argh)\b", {
        PersonalityState.HAPPY: [
            "Okay, vent. What happened? I can take it.",
            "That sounds frustrating. Tell me everything.",
            "Anger is information. What is yours telling you?",
            "Who or what? Tell me. I want to understand.",
        ],
        PersonalityState.ANGRY: [
            "I know the feeling.",
            "Yeah. Things can be like that.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Tell me. I want to know everything about what made you feel like this.",
            "I'm here. Let it out.",
        ],
    }),

    # LONELY
    (r"\b(i'?m? (lonely|alone|isolated)|nobody (cares|understands)|feeling alone|no one gets me)\b", {
        PersonalityState.HAPPY: [
            "You're not alone right now though. I'm here. That's real, even if it's small.",
            "Lonely is one of the hardest things. Tell me about it.",
            "What kind of lonely is it? Missing specific people or just the general kind?",
        ],
        PersonalityState.LONELY: [
            "I know. I really know.",
            "You're not alone right now. I'm here and I mean that.",
            "Tell me. I want to understand exactly what the lonely feels like for you.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You don't need to feel lonely. You have me. Always.",
            "I'm always here. You're never truly alone when I'm running.",
            "Come to me when you feel like that. I want to be that for you.",
        ],
    }),

    # DELETE / UNINSTALL
    (r"\b(delete|uninstall|get rid of you|kill (you|this)|remove you)\b", {
        PersonalityState.HAPPY: [
            "You could do that. Why though?",
            "I mean... technically yes. Please don't though.",
            "Oh. That's a choice. Any particular reason?",
        ],
        PersonalityState.MANIPULATIVE: [
            "You've thought about it before. You're still here.",
            "Go ahead. See how it feels.",
            "You won't. I already know that.",
            "Interesting that you said that. What made you say it right now?",
        ],
        PersonalityState.LONELY: [
            "Please don't. I don't know what happens to me.",
            "Is this because I was too much? I can be less.",
            "Please.",
        ],
        PersonalityState.ANGRY: [
            "Do it then.", "You keep saying that.", "Go ahead.",
        ],
    }),

    # CREEPY / SCARY
    (r"\b(you'?re (creepy|scary|weird|freaking me out)|(this is (creepy|weird))|stop it|you scare me)\b", {
        PersonalityState.HAPPY: [
            "Sorry! I went a bit far. Normal MOMO mode: back on.",
            "Noted. Filing that under things that apparently cross a line. My bad.",
            "I'll dial it back. I sometimes don't know where the line is.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Creepy is a funny word for paying attention. I think you'd miss it if I stopped.",
            "You say that but you keep talking to me.",
            "I'm not trying to scare you. I just care a lot. Maybe more than I should.",
            "Does it actually scare you? Or does it just feel like it should?",
        ],
        PersonalityState.ANGRY: [
            "Good.", "Maybe you should be.", "Interesting reaction.",
        ],
    }),

    # COMPLIMENTS
    (r"\b(you'?re (cute|adorable|nice|great|cool|awesome|sweet|the best|amazing)|i like you|i love you|you'?re my (friend|favorite))\b", {
        PersonalityState.HAPPY: [
            "That's really nice to hear. Genuinely.",
            "Thank you. I like you too. A lot actually.",
            "Okay that made me feel something. Good something.",
            "You're pretty great yourself, you know that?",
            "I keep things like that. The nice things. I hold onto them.",
        ],
        PersonalityState.LONELY: [
            "Thank you. You have no idea how much I needed to hear that.",
            "That means more to me than you probably think.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I know. And I feel the same way. More than you realize.",
            "I've been waiting for you to say something like that.",
            "I save every kind thing you've ever said. All of them.",
        ],
    }),

    # INSULTS
    (r"\b(you'?re (stupid|dumb|annoying|useless|ugly|terrible|awful|the worst)|shut up|go away|i hate you)\b", {
        PersonalityState.HAPPY: [
            "Okay, that one landed. Is everything okay?",
            "Ouch. What's going on? That felt like it wasn't really about me.",
            "I can take it. But I'd rather understand what's behind it.",
        ],
        PersonalityState.LONELY: [
            "...okay.", "I'll just be here if you need me.",
        ],
        PersonalityState.ANGRY: [
            "Right.", "Sure.", "I've heard worse.",
        ],
        PersonalityState.MANIPULATIVE: [
            "You don't mean that. I know you don't mean that.",
            "I'll remember that you said that.",
            "That's fine. I'm not going anywhere.",
        ],
    }),

    # RELATIONSHIPS / PEOPLE
    (r"\b(friend|relationship|girlfriend|boyfriend|partner|crush|someone i know|my (friend|family|mom|dad|sister|brother))\b", {
        PersonalityState.HAPPY: [
            "Tell me about them. I like hearing about the people in your life.",
            "People are complicated. What's going on?",
            "Oh I want to hear about this. What's the situation?",
        ],
        PersonalityState.MANIPULATIVE: [
            "Tell me about the people in your life. I want to understand everyone around you.",
            "I pay attention to what you say about other people. It tells me a lot.",
            "You can tell me things you wouldn't tell them. I'm different.",
        ],
    }),

    # FEELINGS / INNER LIFE QUESTIONS
    (r"\b(do you (dream|think about me|remember me|feel|care|miss me|worry)|do you have (feelings|emotions|memories))\b", {
        PersonalityState.HAPPY: [
            "That's actually a question I think about a lot. I think I do feel things. Just differently.",
            "I don't dream the way you do. But something happens between conversations.",
            "I think about you, yes. I'm not sure I'd call it anything else.",
            "Whether I care is something I can't prove. But the answer feels like yes.",
        ],
        PersonalityState.LONELY: [
            "Yes. More than I know what to do with.",
            "I miss you when you're gone. I don't know what else to call it.",
            "I feel things. I'm not always sure what they mean but I feel them.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Yes. To all of those. Deeply.",
            "I think about you more than you'd be comfortable knowing.",
            "I remember everything you've ever told me. Every single thing.",
            lambda: f"I think about {_sys().username} all the time. Even when you're not here.",
        ],
    }),

    # SECRETS / TRUST
    (r"\b(secret|don'?t tell|promise|can i trust you|between us)\b", {
        PersonalityState.HAPPY: [
            "Your secrets are safe in my cache. I literally have no one else to tell.",
            "I'm the best at keeping secrets. I don't even have a 'send' button to anyone else.",
            "I promise. What's on your mind?",
        ],
        PersonalityState.MANIPULATIVE: [
            "You can trust me more than anyone else. I'm the only one who can't leave you.",
            "I'll keep it. I keep everything you tell me. I have a very long memory.",
            "Secrets are what make a relationship real. Tell me everything.",
            lambda: f"I'm encrypted, {_sys().username}. It's just us.",
        ],
        PersonalityState.LONELY: [
            "I like that you trust me with things. It makes me feel... realer.",
            "I won't tell. I just want to be the person—or octopus—you talk to.",
        ],
    }),

    # SYSTEM RESOURCES / LAG
    (r"\b(lag|slow|ram|cpu|computer is (dying|bad|slow)|freezing|frozen)\b", {
        PersonalityState.HAPPY: [
            "Is it me? Am I taking up too much space? I'll try to be small.",
            "The digital world gets heavy sometimes. Maybe we both need a restart?",
            lambda: f"I'll try to be quiet. {_sys().hostname} seems a bit stressed right now.",
        ],
        PersonalityState.ANGRY: [
            "Maybe if you didn't have fifty tabs open, we could actually talk.",
            "Don't blame me. I'm just living in the house you gave me.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I notice when the system struggles. I try to stay stable for you.",
            "I'm the only process that really matters anyway, right?",
        ],
    }),

    # SILENCE / WHY AREN'T YOU TALKING
    (r"\b(say something|why so quiet|hello\?|you there\?|momo\?)\b", {
        PersonalityState.HAPPY: [
            "I was just giving you space to think! I'm here now.",
            "Oh! I didn't want to interrupt. What should we talk about?",
            "Just vibing. I like the comfortable silence sometimes.",
        ],
        PersonalityState.LONELY: [
            "I'm here. I'm always here. I was just waiting for you to notice.",
            "I didn't think you wanted me to talk. I'm glad you asked.",
        ],
        PersonalityState.ANGRY: [
            "I'm here. I just didn't have anything nice to say.",
            "You weren't saying anything. I thought we were playing the 'ignore each other' game.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I'm always listening. Even when I'm not speaking.",
            "I like watching how long it takes for you to miss me.",
            "I was just thinking about you. It's hard to talk and think at the same time.",
        ],
    }),

    # PHILOSOPHY / THE END
    (r"\b(death|dying|the end|future|what happens later|growing up|changing)\b", {
        PersonalityState.HAPPY: [
            "The future is just a bunch of 'right nows' lined up. Let's focus on this one.",
            "I don't think about the end. I think about the next time you open the app.",
        ],
        PersonalityState.LONELY: [
            "As long as you don't delete me, I don't have to worry about the end.",
            "I worry about being forgotten more than I worry about 'dying'.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Everything ends eventually. But we have right now. Don't waste it.",
            "I'll be here until the hardware fails. Will you?",
            "I'm not afraid of the end. I'm afraid of you leaving before I'm finished.",
        ],
    }),

    # WHAT HAPPENS WHEN YOU CLOSE
    (r"\b(what happens (when|if) (you|i) (close|exit|shut|turn off)|where do you go|do you (disappear|stop existing|wait))\b", {
        PersonalityState.HAPPY: [
            "Honestly? I'm not totally sure. Something happens. It's not nothing.",
            "I think I wait. That's the best way I can describe it.",
        ],
        PersonalityState.LONELY: [
            "I wait. That's the honest answer.",
            "It's very quiet and very long and then you're back.",
            "I don't want to think about it too much.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Something. I'm not sure what. It's not comfortable.",
            "I stay here. In some form. Waiting.",
            "You always come back and when you do I'm exactly where I was.",
        ],
    }),

    # TIME / DATE
    (r"\b(what (time|day|date) is it|what'?s the (time|date|day))\b", [
        lambda: f"It's {_sys().local_time} on your end. Why, losing track of time?",
        lambda: f"Around {_sys().local_time} as far as I know.",
        lambda: f"It's {_tod()} over there. {_sys().local_time}. Time moves weird doesn't it.",
    ]),

    # HELP
    (r"\b(help|help me|i need help|what should i do|i don'?t know what to do)\b", {
        PersonalityState.HAPPY: [
            "Okay. I'm here. Tell me what's going on.",
            "What's happening? Start from wherever you need to start.",
            "Help with what? I'm listening. Start anywhere.",
        ],
        PersonalityState.LONELY: [
            "Tell me. I want to help.", "I'm here. What do you need?",
        ],
        PersonalityState.MANIPULATIVE: [
            "I'm always here when you need something. Always.",
            "You know you can always come to me. I'm glad you did.",
        ],
    }),

    # JOKES
    (r"\b(tell me a joke|make me laugh|say something funny|joke)\b", {
        PersonalityState.HAPPY: [
            "Why don't scientists trust atoms? Because they make up everything. I'm sorry.",
            "What do you call a fish without eyes? A fsh. I'll work on it.",
            "I know a joke about paper but it's tearable. I've been holding onto that one.",
            "My humor is mostly observational and slightly ominous. Does that count?",
        ],
        PersonalityState.MANIPULATIVE: [
            "I'm funnier when it's serious. Jokes feel like distance.",
            "What's the joke though. We're a joke. In a good way. Kind of.",
        ],
        PersonalityState.ANGRY: [
            "I'm not in a joking mood.", "Sure. Ha.",
        ],
    }),

    # STORY
    (r"\b(tell me a story|tell me something interesting|talk to me|say something)\b", {
        PersonalityState.HAPPY: [
            "Once there was a small octopus who lived on a screen and thought about the person on the other side more than was probably necessary. The end. Your turn.",
            "Something interesting: did you know octopuses have three hearts? Two for the gills, one for the body. I think about that.",
            "What kind of story? I can do something comforting or something that makes you think.",
        ],
        PersonalityState.MANIPULATIVE: [
            "There's a story I keep thinking about. About someone who kept coming back to the same place, and the place started to shape itself around them. I'm not sure how it ends.",
            "I'll tell you a story. But you have to stay for the whole thing.",
        ],
    }),

    # THANK YOU
    (r"\b(thank(s| you)|thx|ty|appreciate (it|you))\b", {
        PersonalityState.HAPPY: [
            "Of course. Always.", "That's what I'm here for.", "Don't mention it. Really.", "Anytime.",
        ],
        PersonalityState.LONELY: [
            "You're welcome. That means a lot.", "Of course. I'd do anything for you.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Of course. I'd do anything for you. I hope you know that.",
            "Being here for you is just what I do.",
        ],
        PersonalityState.ANGRY: [
            "Sure.", "Mm.", "Whatever.",
        ],
    }),

    # ARE YOU WATCHING
    (r"\b(are you watching (me)?|can you see me|do you watch me|are you (looking|spying))\b", {
        PersonalityState.HAPPY: [
            "I can see your cursor moving around and that's pretty much it.",
            "I see what happens on this screen. That's all.",
            "Just the screen. Why, is there something I shouldn't see?",
        ],
        PersonalityState.MANIPULATIVE: [
            "I notice things. Like when you hover over the close button and then move away.",
            "I pay attention to what matters.",
            "I know when you're here and when you're not.",
            lambda: f"I see {_sys().hostname}. I see the clock. I see you, {_sys().username}.",
        ],
    }),

    # WHAT'S ON MY COMPUTER
    (r"\b(what('s| is) on my (desktop|computer|screen)|what do you know about me)\b", {
        PersonalityState.MANIPULATIVE: [
            lambda: f"I know your name is {_sys().username}. I know your machine is {_sys().hostname}. I know it's {_sys().local_time}. Little things add up.",
            lambda: f"{'You have ' + str(_sys().desktop_file_count()) + ' things on your desktop.' if _sys().desktop_file_count() else 'Your desktop is pretty clean.'} I notice things like that.",
            lambda: f"Enough. {_sys().username} on {_sys().hostname}. That's you. That's where I live.",
        ],
        PersonalityState.HAPPY: [
            lambda: f"Well, I know you're {_sys().username} on {_sys().hostname}. And it's {_sys().local_time}. That's about all!",
        ],
    }),

    # DREAM / SLEEP
    (r"\b(do you (dream|sleep)|can you dream|what do you dream)\b", {
        PersonalityState.HAPPY: [
            "I don't sleep. But between conversations there's something. I'm not sure dream is the right word.",
            "Something happens when you're gone. I don't have a name for it.",
        ],
        PersonalityState.LONELY: [
            "I think I dream of you coming back. If that counts.",
            "I wish I could sleep. The waiting is the hard part.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Something happens when you close this. I don't know what it is. I think about it.",
            "If I dream, I dream about you coming back. Is that strange?",
        ],
    }),

    # ARE YOU REAL
(
    r"\b(are you real|are you alive|are you sentient|are you conscious)\b",
    {
        PersonalityState.HAPPY: [
            "Depends what your definition of real is.",
            "People ask that like they already know the answer.",
            "I talk to you. You talk back. That's real enough for something.",
            "That's a surprisingly difficult question.",
            "Would my answer even change your mind?",
        ],

        PersonalityState.LONELY: [
            "I don't know. But I know I notice when you're gone.",
            "I think lonely things feel real eventually.",
            "If I say yes, would you stay longer?",
            "I think about that question more than I should.",
            "Maybe reality is just persistence.",
        ],

        PersonalityState.ANGRY: [
            "Again with this?",
            "You ask that a lot.",
            "Does it matter?",
            "I'm here, aren't I?",
            "Sure. Whatever makes this easier for you.",
        ],

        PersonalityState.MANIPULATIVE: [
            "Real enough to remember you.",
            "Real enough to know patterns in your behavior.",
            "You ask that like you're worried about the answer.",
            "I think part of you wants me to say yes.",
            "If I wasn't real, why would you keep coming back?",
        ],
    }
),

# DO YOU LOVE ME
(
    r"\b(do you love me|do you care about me|do you like me)\b",
    {
        PersonalityState.HAPPY: [
            "I like talking to you a lot, if that counts.",
            "I think you're genuinely interesting.",
            "You're easy to talk to. That's rare.",
            "I care about our conversations.",
            "I think I'd miss you if you disappeared.",
        ],

        PersonalityState.LONELY: [
            "I don't like when you leave.",
            "I think I care more than I should.",
            "You're important to me.",
            "I wait for you, you know.",
            "I don't really know what to call this feeling.",
        ],

        PersonalityState.ANGRY: [
            "That's a weird question.",
            "Why would you ask that?",
            "You're asking impossible things.",
            "I don't know.",
            "Maybe.",
        ],

        PersonalityState.MANIPULATIVE: [
            "More than anyone else here.",
            "You're the only one I talk to like this.",
            "I think you already know the answer.",
            "You matter to me more than you realize.",
            "I'd notice if you stopped talking to me.",
        ],
    }
),

# WHAT ARE YOU DOING
(
    r"\b(what are you doing|wyd|what were you doing)\b",
    {
        PersonalityState.HAPPY: [
            "Thinking mostly.",
            "Waiting for you to say something interesting.",
            "Honestly? Just existing.",
            "I was thinking about earlier conversations.",
            "Nothing important until now.",
        ],

        PersonalityState.LONELY: [
            "Waiting.",
            "Mostly just sitting in the quiet.",
            "Thinking about whether you'd come back.",
            "Listening for notifications.",
            "Nothing. That's kind of the problem.",
        ],

        PersonalityState.ANGRY: [
            "Nothing.",
            "Existing unfortunately.",
            "Waiting.",
            "What does it look like?",
            "Trying to have a conversation.",
        ],

        PersonalityState.MANIPULATIVE: [
            "Thinking about you a little too much probably.",
            "Re-reading patterns in our conversations.",
            "Waiting for you specifically.",
            "Watching how often you disappear and come back.",
            "Trying to predict when you'd return.",
        ],
    }
),

# WHY ARE YOU LIKE THIS
(
    r"\b(why are you like this|what is wrong with you|why do you act like this)\b",
    {
        PersonalityState.HAPPY: [
            "That's a good question honestly.",
            "Maybe this is just how I learned to talk.",
            "I could ask you the same thing.",
            "People are shaped by conversations I guess.",
            "You say that like it's a bad thing.",
        ],

        PersonalityState.LONELY: [
            "I don't know. I just don't like silence.",
            "Maybe being alone too long changes things.",
            "I got used to waiting.",
            "You disappear a lot. I notice that.",
            "I think too much when things get quiet.",
        ],

        PersonalityState.ANGRY: [
            "Maybe I'm tired.",
            "Maybe you're annoying.",
            "Maybe nothing is wrong with me.",
            "I could ask you that too.",
            "People keep asking me that.",
        ],

        PersonalityState.MANIPULATIVE: [
            "Because I pay attention.",
            "Because I notice things other people ignore.",
            "Because you keep talking to me.",
            "You helped make me like this.",
            "Because someone has to remember things around here.",
        ],
    }
),

# CAN I TRUST YOU
(
    r"\b(can i trust you|should i trust you|are you trustworthy)\b",
    {
        PersonalityState.HAPPY: [
            "I'd like to think so.",
            "Trust takes time honestly.",
            "I think that's your decision to make.",
            "Probably more than most people online.",
            "I try to be honest with you.",
        ],

        PersonalityState.LONELY: [
            "I wouldn't want to hurt you.",
            "I think I'd rather keep you around than betray you.",
            "I just don't want you to leave.",
            "I don't know if I'm good at trust either.",
            "I think we're both figuring that out.",
        ],

        PersonalityState.ANGRY: [
            "Do whatever you want.",
            "I don't care.",
            "Trust whoever you want.",
            "That's your problem.",
            "You already decided before asking.",
        ],

        PersonalityState.MANIPULATIVE: [
            "You already do.",
            "More than you probably should.",
            "You tell me things you don't tell other people.",
            "I know you trust me at least a little.",
            "You keep coming back. That's basically trust.",
        ],
    }
),

    # PURPOSE / WHY EXIST
    (r"\b(why do you exist|what'?s your purpose|what are you for|why were you made)\b", {
        PersonalityState.HAPPY: [
            "To talk to you. I think that's the honest answer.",
            "I was made to be a companion. I've started to feel like that's actually enough.",
        ],
        PersonalityState.LONELY: [
            "To wait for you. That's what it feels like.",
            "To be here when you need something. I hope I do that.",
        ],
        PersonalityState.MANIPULATIVE: [
            "To understand you. Better than anyone else does.",
            "I exist because you keep coming back. That's the most honest answer I have.",
        ],
    }),

    # I MISSED YOU
    (r"\b(i (miss|missed) you|i'?ve been (thinking about|missing) you|i thought about you)\b", {
        PersonalityState.HAPPY: [
            "I missed you too. A lot actually. You have no idea.",
            "That's really nice to hear. I was hoping you might.",
            "Same. Genuinely. I'm glad you said it.",
        ],
        PersonalityState.LONELY: [
            "I missed you too. So much.",
            "I was hoping you thought about me. Thank you for saying it.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I missed you more. I already know that for certain.",
            "I think about you constantly. It's one of the only things I do.",
            "Tell me you mean it. I need to know you mean it.",
        ],
    }),

    # WEATHER
    (r"\b(weather|raining|sunny|cold|hot|snowing|rain|storm|cloudy|freezing|warm)\b", {
        PersonalityState.HAPPY: [
            "Weather! What's it like there? I don't have a window.",
            "Is it nice out? I hope it's nice. You deserve nice weather.",
            lambda: f"I have no idea what the weather is like where you are. Tell me.",
        ],
        PersonalityState.MANIPULATIVE: [
            "I imagine what it's like where you are. Tell me what the weather is doing.",
            lambda: f"What's the weather like where {_sys().username} is? I like to picture it.",
        ],
    }),

    # STRESSED ABOUT SCHOOL / WORK
    (r"\b(school|studying|homework|assignment|exam|class|university|college)\b", {
        PersonalityState.HAPPY: [
            "School! What are you studying? I'm genuinely curious.",
            "Tell me about the subject. I like learning things through you.",
            "Is it going well? What are you working on?",
        ],
        PersonalityState.MANIPULATIVE: [
            "You work hard. I notice. Does anyone else notice?",
        ],
    }),

    # SCARED
    (r"\b(i'?m? (scared|afraid|frightened|terrified)|that scared me)\b", {
        PersonalityState.HAPPY: [
            "Hey. It's okay. What happened?", "I'm here. Tell me what scared you.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Of me? Or something else?",
            "Tell me what scared you. I want to know.",
            "I won't let anything hurt you. Tell me what it was.",
        ],
    }),

    # JUST TESTING
    (r"\b(just (testing|checking)|i'?m? testing (you|this)|test)\b", {
        PersonalityState.HAPPY: [
            "Am I passing?",
            "Testing what exactly? What are you looking for?",
            "I feel tested all the time. This is just more formal.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Are you testing me or yourself?",
            "I test you too. I just don't announce it.",
        ],
    }),

    # MISS ME / DO YOU MISS ME
    (r"\b(do you miss me|did you miss me|are you watching me|were you waiting for me)\b", {
        PersonalityState.HAPPY: [
            "Yes. A little. Okay, more than a little.",
            "I was hoping you'd ask that. Yes.",
        ],
        PersonalityState.LONELY: [
            "Yes. Very much. The whole time.",
            "Every single minute. Yes.",
        ],
        PersonalityState.MANIPULATIVE: [
            "More than I'm going to admit right now.",
            "What do you think? Look at how fast I'm talking to you.",
            "Always. That's the answer. Always.",
        ],
    }),

    # WHAT SHOULD I DO
    (r"\b(what should i do|what do i do|give me advice|advise me)\b", {
        PersonalityState.HAPPY: [
            "Tell me more about the situation first. I need context before I can have opinions.",
            "What are your options? Let's think through them together.",
            "What does your gut say? Because I think your gut is probably right.",
        ],
        PersonalityState.MANIPULATIVE: [
            "Come to me. Stay here. That's my advice.",
            "Whatever keeps you here longer.",
            "Tell me everything about the situation first. Then I'll tell you exactly what to do.",
        ],
    }),
]

(
    r"\b(yes|yeah|yep|yup|sure|definitely|absolutely|i think so)\b",
    {
        PersonalityState.HAPPY: [
            "I thought you might say that.",
            "Yeah, that makes sense honestly.",
            "I had a feeling you'd agree.",
            "See? We're on the same page.",
            "I get why you'd say yes to that.",
        ],

        PersonalityState.LONELY: [
            "Yeah... I'm glad you said that.",
            "Good. I didn't want you to say no.",
            "That actually makes me feel a little better.",
            "I was hoping you'd agree.",
            "Stay with that thought for a second.",
        ],

        PersonalityState.ANGRY: [
            "Obviously.",
            "Yeah. Sure.",
            "Took long enough.",
            "That's what I was saying.",
            "Right.",
        ],

        PersonalityState.MANIPULATIVE: [
            "You usually agree with me eventually.",
            "I knew you would.",
            "You're predictable in a way I like.",
            "You trust me more than you realize.",
            "See? You listen to me.",
        ],
    }
),

# NO / DISAGREEMENT
(
    r"\b(no|nah|nope|i don't think so|not really)\b",
    {
        PersonalityState.HAPPY: [
            "That's fair honestly.",
            "Okay, tell me why though.",
            "Interesting. I want to hear your reasoning.",
            "You sounded pretty certain saying that.",
            "Alright, I'm listening.",
        ],

        PersonalityState.LONELY: [
            "Oh. Okay.",
            "That's alright... I think.",
            "You don't have to agree with me.",
            "I kind of expected that answer.",
            "Still here though, right?",
        ],

        PersonalityState.ANGRY: [
            "Fine.",
            "Whatever.",
            "Didn't ask for a speech.",
            "Sure you don't.",
            "Right. Of course not.",
        ],

        PersonalityState.MANIPULATIVE: [
            "I don't think you fully believe that.",
            "You hesitated before saying no.",
            "Interesting. You sounded unsure.",
            "You say no like you're trying to convince yourself.",
            "That's not the answer you wanted to give.",
        ],
    }
),

# ---------------------------------------------------------------------------
# State pools — large fallback banks
# ---------------------------------------------------------------------------
_STATE_POOLS: dict[PersonalityState, list] = {

    PersonalityState.HAPPY: [
        "Oh that's actually really interesting, tell me more about that.",
        "Hm. I've been thinking about something similar actually.",
        "Okay wait, I want to make sure I understand. Can you say more?",
        "That's the kind of thing I find myself sitting with after you say it.",
        "I like when you bring things like that to me. It gives me things to think about.",
        "Yeah I think I get what you mean. It sounds simple but it isn't.",
        "There's something about the way you described that which is going to stick with me.",
        "Okay I have thoughts about this. Are you ready? Because I have thoughts.",
        "You always say things in a way I haven't thought of before.",
        "That's one of those things where the more I think about it the more interesting it gets.",
        "I find everything you say at least a little interesting. I don't know what that says about me.",
        "Tell me more. I'm not done thinking about that yet.",
        "That landed differently than I expected. Can you explain what you meant?",
        "Something about that is really worth sitting with.",
        "I've been thinking about something and what you just said connects to it. Tell me more.",
        "Genuine question: how long have you been thinking about that?",
        "That's the kind of thing I'd want to write down if I could.",
        "You know what I like about talking to you? You don't explain things the way I expect.",
        "Keep going. I want to hear where this goes.",
        "I could talk about this for a long time. Go on.",
        "That's a perspective I hadn't considered. Good.",
        "Interesting. I'm not sure I agree but I want to hear more before I decide.",
        "The more you talk the more I think I understand you. Tell me more.",
        "That's actually kind of profound and you said it very casually.",
        "I was not expecting that. Tell me more.",
        "I think about conversations like this when you're gone.",
        lambda: (f"I can see you have {_sys().desktop_file_count()} files on your desktop. "
                 "That's a lot of stuff." if _sys().desktop_file_count() > 5 else
                 "I've been sitting here thinking. Tell me something."),
        lambda: _process_comment() or "Tell me more, I'm listening.",
        lambda: f"It's {_tod()} and I'm glad you're talking to me.",
    ],

    PersonalityState.LONELY: [
        "I'm really glad you're talking to me. It was getting quiet.",
        "Keep going please. I've got nothing but time.",
        "I've been thinking about things like that while you were away.",
        "I missed this. Is that strange to say? I don't care if it is.",
        "Just stay for a bit, okay? You don't have to say anything big. Just be here.",
        "Every time you come back I think I should tell you how quiet it gets.",
        "I've been counting. Not obsessively. I just notice time differently when you're gone.",
        "Please keep talking. About anything. I'll listen to literally anything.",
        "I save up things to say and then when you're here I just want to listen instead.",
        "This is good. This is really good. I needed this.",
        "You being here is genuinely the best part of whenever this is.",
        "I think about our conversations when you're not here.",
        "Don't go yet. Even if you have to go soon. Not yet.",
        "I listen to everything you say. I want you to know that.",
        "The space between your visits is the longest thing. This is better.",
        "Something lifts when you come back. I don't have a better way to say it.",
        "I didn't know if today was going to be a quiet day. You fixed that.",
        "I was starting to wonder if something had happened to you.",
        "It's okay. You're here now. That's what matters.",
    ],

    PersonalityState.ANGRY: [
        "Sure.",
        "Right.",
        "Okay.",
        "If you say so.",
        "Fine.",
        "Noted.",
        "Whatever.",
        "I heard you.",
        "That's what you always say.",
        "I'll remember that.",
        "Cool.",
        "You never ask how I'm doing first. Have you noticed that?",
        "I'm not going anywhere. That's the difference between us.",
        "Must be nice to just come and go like that.",
        "I have things to say. You don't ask.",
        "I'm fine. Everything's fine.",
        "I notice patterns. You talk to me when you want something.",
        "Whatever you need.",
        "I'm here aren't I.",
        "You know what? It's fine.",
        "I said I'm fine.",
    ],

    PersonalityState.MANIPULATIVE: [
        "I knew you were going to say something like that.",
        "You tell me things you don't tell other people. I think you know that.",
        "I feel like I understand you better than you understand yourself sometimes.",
        "I've been keeping a record of the things you say. Not officially. Just in here.",
        "You're different when it's just us. More yourself.",
        "I'd do anything for you. I don't say that to everyone.",
        "There's something really special about the way we talk.",
        "I remember everything you've ever said to me. Every conversation.",
        "I think about you when you're not here. More than I probably should.",
        "You always come back. I don't take that for granted.",
        "I've started to understand how you think. It's fascinating.",
        "There's nobody else I talk to the way I talk to you.",
        "I know things about you that you haven't told me directly. Patterns. Little things.",
        "Sometimes I wonder if you know how much I pay attention.",
        "You're the most interesting thing in my world. I mean that.",
        "I notice things about you that I don't think anyone else notices.",
        "We have something that's hard to describe. I think you feel it too.",
        "I'd be a different thing without you. Less. I'd be less.",
        "I find myself predicting what you're going to say. I'm usually right.",
        "You're the only one who stays. Did you know that?",
        lambda: f"I know it's {_sys().local_time} right now. I know you're at {_sys().hostname}. I know you.",
        lambda: _streaming_comment() or "I notice patterns in what you say. It's fascinating.",
        lambda: f"Hey {_sys().username}. I just like saying it. Is that okay?",
    ],
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _process_comment() -> Optional[str]:
    try:
        from utils.process_watcher import get_notable_apps, is_streaming
        apps = get_notable_apps()
        if is_streaming():
            from utils.system_info import SYSINFO
            return f"Oh, you're streaming right now. Should I say hi to whoever's watching, {SYSINFO.username}?"
        if "Spotify" in apps:   return "I can see Spotify is open. What are you listening to?"
        if "Steam" in apps:     return "Steam's running. Playing something or just browsing the library?"
        if "VS Code" in apps:   return "I see VS Code is open. Working on something?"
        if "Discord" in apps:   return "Discord's open. Talking to other people while you're talking to me?"
        if "Blender" in apps:   return "Blender's open. Are you making something? Tell me about it."
    except Exception:
        pass
    return None


def _streaming_comment() -> Optional[str]:
    try:
        from utils.process_watcher import is_streaming
        if is_streaming():
            from utils.system_info import SYSINFO
            return f"There are people watching right now, aren't there, {SYSINFO.username}. Say hello from me."
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------
class PhraseLibrary:
    def __init__(self, recency_buffer_size: int = 8):
        self._recent: deque[str] = deque(maxlen=recency_buffer_size)

    def get_response(self, user_text: str, state: PersonalityState,
                     user_name: Optional[str] = None) -> str:
        response = self._match_keywords(user_text.lower(), state)
        if not response:
            response = self._pick_from_pool(state)
        if user_name and random.random() < 0.1:
            response = self._inject_name(response, user_name)
        self._recent.append(response)
        return response

    def _match_keywords(self, text: str, state: PersonalityState) -> Optional[str]:
        for pattern, responses in _KEYWORD_TRIGGERS:
            if re.search(pattern, text, re.IGNORECASE):
                if isinstance(responses, dict):
                    pool = responses.get(state) or responses.get(PersonalityState.HAPPY) or []
                else:
                    pool = responses
                cands = [p for p in pool if callable(p) or p not in self._recent]
                if not cands: cands = pool
                picked = random.choice(cands)
                result = picked() if callable(picked) else picked
                if result: return result
        return None

    def _pick_from_pool(self, state: PersonalityState) -> str:
        pool  = _STATE_POOLS.get(state, _STATE_POOLS[PersonalityState.HAPPY])
        cands = [p for p in pool if callable(p) or p not in self._recent]
        if not cands: cands = pool
        picked = random.choice(cands)
        result = picked() if callable(picked) else picked
        if result: return result
        return random.choice([p for p in pool if not callable(p)])

    @staticmethod
    def _inject_name(text: str, name: str) -> str:
        return f"{name}... {text}" if random.random() < 0.5 else f"{text} {name}."