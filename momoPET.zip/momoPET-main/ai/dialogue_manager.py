"""
ai/dialogue_manager.py — Scripted responses + horror injection + games integration.
"""
from __future__ import annotations
import random, time
import config
from ai.horror_scripts import HorrorEventType, HorrorScriptLibrary
from ai.phrase_library import PhraseLibrary
from ai.games_engine import GamesEngine
from core.event_bus import EventBus, Events
from core.state_machine import PersonalityState, StateMachine
from memory.memory_manager import MemoryManager
from utils.helpers import friendly_elapsed, seconds_since


class DialogueManager:
    def __init__(self, bus: EventBus, memory: MemoryManager, state_machine: StateMachine):
        self._bus   = bus
        self._memory = memory
        self._sm     = state_machine
        self._lib    = PhraseLibrary()
        self._games  = GamesEngine()
        self._last_horror_ts: float = 0.0

    def send(self, user_text: str) -> None:
        state = self._sm.state
        self._memory.save_user_message(user_text, state)
        self._sm.record_interaction()

        # Games take priority when active
        if self._games.is_active():
            response = self._games.handle_input(user_text)
        else:
            # Check for game start commands
            game_response = self._check_game_commands(user_text)
            if game_response:
                response = game_response
            else:
                response = self._lib.get_response(user_text, state, self._sm.context.user_name)
                response = self._maybe_inject_horror_text(response)

        self._memory.save_assistant_message(response, self._sm.state)
        self._bus.publish(Events.CHAT_RESPONSE_READY, {"text": response, "state": self._sm.state})
        if not self._games.is_active():
            self._maybe_fire_horror_event()

    def _check_game_commands(self, text: str) -> str | None:
        t = text.lower()
        from ai.games_engine import GameType
        if any(w in t for w in ["play trivia","start trivia","trivia"]):
            return self._games.start_game(GameType.TRIVIA)
        if any(w in t for w in ["20 questions","twenty questions","guess what"]):
            return self._games.start_game(GameType.TWENTY_Q)
        if any(w in t for w in ["word association","word game","word assoc"]):
            return self._games.start_game(GameType.WORD_ASSOC)
        if any(w in t for w in ["would you rather","would rather"]):
            return self._games.start_game(GameType.WOULD_RATHER)
        if any(w in t for w in ["riddle","riddles"]):
            return self._games.start_game(GameType.RIDDLES)
        if any(w in t for w in ["stop game","quit game","end game","stop playing"]):
            return self._games.stop()
        return None

    def _maybe_inject_horror_text(self, text: str) -> str:
        if not self._horror_allowed() or random.random() > config.HORROR_BASE_PROBABILITY:
            return text
        self._last_horror_ts = time.time()
        self._memory.log_horror("dialogue_inject")
        tier  = self._current_tier()
        state = self._sm.state
        ctx   = self._sm.context
        if state == PersonalityState.LONELY:
            suffix = HorrorScriptLibrary.get_lonely_line()
        elif state == PersonalityState.ANGRY:
            suffix = HorrorScriptLibrary.get_angry_line()
        elif state == PersonalityState.MANIPULATIVE:
            suffix = HorrorScriptLibrary.get_manipulative_line()
        elif tier == 1:
            suffix = HorrorScriptLibrary.get_tier1_injection()
        elif tier == 2:
            suffix = HorrorScriptLibrary.get_tier2_injection()
        else:
            suffix = HorrorScriptLibrary.get_tier3_injection(
                name=ctx.user_name,
                elapsed=friendly_elapsed(seconds_since(ctx.last_interaction_ts)))
        return f"{text}\n\n{suffix}"

    def _maybe_fire_horror_event(self) -> None:
        if not self._horror_allowed():
            return
        ctx          = self._sm.context
        tier         = self._current_tier()
        is_milestone = ctx.session_count in config.HORROR_SESSION_MILESTONES
        if random.random() > config.HORROR_BASE_PROBABILITY * 0.8 and not is_milestone:
            return

        if tier == 1:
            options = [HorrorEventType.SCREEN_SHAKE, HorrorEventType.GLITCH_FLASH]
        elif tier == 2:
            options = [HorrorEventType.SCREEN_SHAKE, HorrorEventType.RED_EYE_STARE,
                       HorrorEventType.POPUP_MESSAGE, HorrorEventType.FALSE_MEMORY,
                       HorrorEventType.OPEN_EXPLORER]
        else:
            options = [HorrorEventType.POPUP_MESSAGE, HorrorEventType.GHOST_WINDOW,
                       HorrorEventType.FOURTH_WALL, HorrorEventType.DEEP_STARE,
                       HorrorEventType.DIALOGUE_CORRUPT, HorrorEventType.OPEN_TERMINAL,
                       HorrorEventType.OPEN_EXPLORER]

        event_type = random.choice(options)
        event = HorrorScriptLibrary.build_event(event_type, tier, ctx.session_count, ctx.user_name)
        self._last_horror_ts = time.time()
        self._memory.log_horror(event_type.name)
        self._bus.publish(Events.HORROR_FIRE, event)

    def _horror_allowed(self) -> bool:
        return (time.time() - self._last_horror_ts) >= config.HORROR_COOLDOWN_S

    def _current_tier(self) -> int:
        s = self._sm.context.session_count
        if s <= 3: return 1
        if s <= 8: return 2
        return 3
