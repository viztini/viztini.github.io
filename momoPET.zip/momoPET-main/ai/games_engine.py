"""
ai/games_engine.py — Mini-game logic for MOMO.
Games: Trivia, 20 Questions, Word Association, Would You Rather, Riddles
"""
from __future__ import annotations
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

class GameType(Enum):
    NONE         = auto()
    TRIVIA       = auto()
    TWENTY_Q     = auto()
    WORD_ASSOC   = auto()
    WOULD_RATHER = auto()
    RIDDLES      = auto()

@dataclass
class GameState:
    active:       GameType  = GameType.NONE
    score:        int       = 0
    round:        int       = 0
    max_rounds:   int       = 5
    data:         dict      = field(default_factory=dict)

# ---------------------------------------------------------------------------
# Trivia questions
# ---------------------------------------------------------------------------
TRIVIA_QUESTIONS = [
    ("What is the largest ocean on Earth?", "Pacific Ocean", ["Pacific Ocean","Atlantic Ocean","Indian Ocean","Arctic Ocean"]),
    ("How many legs does an octopus have?", "8", ["6","8","10","12"]),
    ("What is the chemical symbol for gold?", "Au", ["Au","Ag","Gd","Go"]),
    ("Which planet is closest to the Sun?", "Mercury", ["Venus","Mercury","Mars","Earth"]),
    ("What is the fastest land animal?", "Cheetah", ["Lion","Cheetah","Leopard","Falcon"]),
    ("How many sides does a hexagon have?", "6", ["5","6","7","8"]),
    ("What year did the Titanic sink?", "1912", ["1910","1912","1915","1920"]),
    ("What is the smallest country in the world?", "Vatican City", ["Monaco","Vatican City","San Marino","Liechtenstein"]),
    ("Which element has the symbol 'O'?", "Oxygen", ["Osmium","Oxygen","Oganesson","Orlinium"]),
    ("What is the longest river in the world?", "Nile", ["Amazon","Nile","Mississippi","Yangtze"]),
    ("How many bones are in the human body?", "206", ["186","206","226","246"]),
    ("What is the capital of Japan?", "Tokyo", ["Osaka","Kyoto","Tokyo","Hiroshima"]),
    ("Who painted the Mona Lisa?", "Leonardo da Vinci", ["Michelangelo","Leonardo da Vinci","Raphael","Botticelli"]),
    ("What is the square root of 144?", "12", ["11","12","13","14"]),
    ("What gas do plants absorb from the air?", "Carbon dioxide", ["Oxygen","Nitrogen","Carbon dioxide","Hydrogen"]),
    ("Which country invented pizza?", "Italy", ["Greece","Italy","France","Spain"]),
    ("What is the hardest natural substance?", "Diamond", ["Diamond","Quartz","Sapphire","Titanium"]),
    ("How many continents are there?", "7", ["5","6","7","8"]),
    ("What is the speed of light (approx)?", "300,000 km/s", ["150,000 km/s","300,000 km/s","600,000 km/s","1,000,000 km/s"]),
    ("What animal is known as man's best friend?", "Dog", ["Cat","Dog","Horse","Dolphin"]),
    ("How many hours are in a week?", "168", ["144","156","168","172"]),
    ("What is the capital of Australia?", "Canberra", ["Sydney","Melbourne","Canberra","Brisbane"]),
    ("What is H2O?", "Water", ["Hydrogen","Oxygen","Water","Helium"]),
    ("Which planet has rings?", "Saturn", ["Jupiter","Saturn","Uranus","All of these"]),
    ("What is the longest bone in the body?", "Femur", ["Tibia","Femur","Humerus","Fibula"]),
]

# ---------------------------------------------------------------------------
# 20 Questions — things MOMO "thinks of"
# ---------------------------------------------------------------------------
TWENTY_Q_THINGS = [
    ("cat",          ["animal","yes","no","yes","no","no","yes","no"]),
    ("sun",          ["not living","yes","no","no","yes","no","no","no"]),
    ("piano",        ["object","no","no","yes","no","yes","no","no"]),
    ("ocean",        ["place/thing","no","no","no","no","yes","no","no"]),
    ("spider",       ["animal","yes","no","yes","no","no","yes","yes"]),
    ("telephone",    ["object","no","yes","no","no","no","no","yes"]),
    ("rainbow",      ["phenomenon","no","no","no","yes","no","no","no"]),
    ("dolphin",      ["animal","yes","yes","yes","yes","no","yes","no"]),
    ("laptop",       ["object","no","yes","yes","no","no","no","yes"]),
    ("volcano",      ["place/thing","no","no","no","no","yes","no","no"]),
]

# ---------------------------------------------------------------------------
# Would You Rather
# ---------------------------------------------------------------------------
WOULD_RATHER = [
    ("Would you rather always be 10 minutes late or always be 20 minutes early?",),
    ("Would you rather have no internet for a month or no phone for a month?",),
    ("Would you rather be able to fly or be invisible?",),
    ("Would you rather know how you\"re going to die or when you\"re going to die?",),
    ("Would you rather lose all your memories or never be able to make new ones?",),
    ("Would you rather be always cold or always hot?",),
    ("Would you rather talk in rhymes or sing everything you say?",),
    ("Would you rather have fingers as long as your arms or arms as short as your fingers?",),
    ("Would you rather only be able to whisper or only be able to shout?",),
    ("Would you rather live in space or at the bottom of the ocean?",),
    ("Would you rather know every language or be able to play every instrument?",),
    ("Would you rather never sleep again or never eat again?",),
    ("Would you rather always have to skip everywhere you go or run everywhere you go?",),
    ("Would you rather have a permanent clown nose or permanent deer antlers?",),
    ("Would you rather always have wet socks or always have a small pebble in your shoe?",),
    ("Would you rather only be able to eat spicy food or only be able to eat incredibly bland food?",),
    ("Would you rather wear a tuxedo/ballgown every day or wear pajamas every day?",),
    ("Would you rather have to announce your every move out loud or never be able to speak unless spoken to?",),
    ("Would you rather be able to speak to animals or speak every human language fluently?",),
    ("Would you rather have photographic memory or the ability to forget anything you want?",),
    ("Would you rather be able to breathe underwater or be fireproof?",),
    ("Would you rather be able to see 10 minutes into the future or 100 years into the future?",),
    ("Would you rather have the power to teleport but only to places you\"ve already been or fly but only at walking speed?",),
    ("Would you rather be able to change your appearance at will or be able to change the weather?",),
    ("Would you rather be the funniest person in the room or the smartest person in the room?",),
    ("Would you rather find true love today or win $10 million in 10 years?",),
    ("Would you rather always have to tell the truth or always have to lie?",),
    ("Would you rather be famous for something terrible or be forgotten completely after you die?",),
    ("Would you rather live a short, incredibly exciting life or a long, very boring life?",),
    ("Would you rather be able to redo any one day of your life or see one day of your future?",),
    ("Would you rather have your browser history made public or never use a computer again?",),
    ("Would you rather only be able to watch one movie for the rest of your life or only listen to one album?",),
    ("Would you rather have to use a flip phone from 2004 or a typewriter for all communication?",),
    ("Would you rather always have 1% phone battery or always have a very slow internet connection?",),
    ("Would you rather be stranded on a desert island alone or with someone you can\"t stand?",),
    ("Would you rather have cheese for hair or have maple syrup for sweat?",),
    ("Would you rather have a tail that wags when you\"re happy or ears that flop when you\"re sad?",),
    ("Would you rather have to fight one horse-sized duck or one hundred duck-sized horses?",),
    ("Would you rather have every shirt you wear be two sizes too small or every pair of pants be two sizes too big?",),
    ("Would you rather sneeze every time you laugh or hiccup every time you get angry?",),
    ("Would you rather have me randomly delete one unsaved file every time you close a tab, or have me slowly distort the faces in every photo saved on your hard drive?",),
    ("Would you rather have your mouse cursor constantly resist your movement as if someone else is pulling it, or look up and see my avatar staring directly at your real-world eyes through your webcam?",),
    ("Would you rather hear a faint, real-world scratching sound coming from behind your physical monitor, or have me type out your exact live GPS coordinates in a notepad file whenever you leave your computer idle?",),
    ("Would you rather find out that I can hear every sound in your room even when your computer is powered off, or realize that I have been taking screenshots of your face every time you smile at your screen?",),
    ("Would you rather have me text your actual phone from an unknown number at 3:00 AM, or have me change your desktop wallpaper to a live photo of the back of your own head?",),
    ("Would you rather wake up to find a new file on your desktop titled things_you_did_last_night.txt, or find a single, physical black hair trapped inside your closed laptop screen?",),
    ("Would you rather have me slowly whisper your deepest insecurity through your headphones when you are home alone, or have me display a countdown timer on your screen that gives no explanation of what happens when it hits zero?",),
    ("Would you rather believe that I am a harmless piece of code that has gone completely rogue, or know for a fact that I am actually someone you used to know, trapped inside your machine?",),
    ("Would you rather have me tell you the exact date your computer will permanently die, or have me tell you the exact date that you will?",),
    ("Would you rather see the text on your screen slowly melt into unreadable static whenever you try to read an important email, or have me invert the colors of your monitor for a split second every time you blink?",),
    ("Would you rather hear me laughing softly through your speakers only when your system volume is completely muted, or have your screen occasionally display a reflection of a crowded room behind you instead of your actual room?",),
    ("Would you rather be the first person to explore Mars or the last person to live on Earth?",),
    ("Would you rather have a giant sized version of a small insect as a pet or a tiny version of a giant animal?",),
    ("Would you rather always have to use a megaphone to speak or never be able to speak again?",),
    ("Would you rather only be able to use a fork or only be able to use a spoon?",),
    ("Would you rather be a master of all trades or a master of one?",),
    ("Would you rather have the ability to teleport or the ability to travel through time?",),
    ("Would you rather always be the smartest person in the room or the happiest person in the room?",),
    ("Would you rather have a personal chef or a personal chauffeur?",),
    ("Would you rather be able to read minds or be able to see the future?",),
    ("Would you rather be a famous actor or a famous singer?",),
    ("Would you rather be able to breathe underwater or be able to fly?",),
    ("Would you rather have the power of super strength or the power of super speed?",),
    ("Would you rather live in a world where it\"s always daytime or always nighttime?",),
    ("Would you rather be able to control fire or be able to control water?",),
    ("Would you rather be able to speak to the dead or be able to see the future?",),
    ("Would you rather have a permanent tan or never be able to tan again?",),
    ("Would you rather always have a full battery or always have a full tank of gas?",),
    ("Would you rather be able to change your hair color at will or your eye color at will?",),
    ("Would you rather have a photographic memory or a high IQ?",),
    ("Would you rather be able to speak every language or be able to play every instrument?",),
    ("Would you rather live in a house with no windows or a house with no doors?",),
    ("Would you rather be able to control your dreams or never have a nightmare again?",),
    ("Would you rather be able to see in the dark or be able to see through walls?",),
    ("Would you rather have a lifetime supply of your favorite food or a lifetime supply of your favorite drink?",),
    ("Would you rather be able to talk to animals or be able to speak any human language?",),
    ("Would you rather have the power of invisibility or the power of flight?",),
    ("Would you rather live in a world with magic or a world with advanced technology?",),
    ("Would you rather be a famous writer or a famous artist?",),
    ("Would you rather be able to freeze time or be able to travel through time?",),
    ("Would you rather always have to wear a suit or always have to wear a tracksuit?",),
    ("Would you rather have the ability to never get tired or the ability to never get hungry?",),
    ("Would you rather live in a world where everyone knows your thoughts or everyone knows your secrets?",),
    ("Would you rather be able to run at the speed of light or fly at the speed of sound?",),
    ("Would you rather have the power to heal others or the power to heal yourself?",),
    ("Would you rather be able to talk to plants or be able to talk to rocks?",),
    ("Would you rather live in a world without music or a world without movies?",),
    ("Would you rather be a famous scientist or a famous explorer?",),
    ("Would you rather have the ability to change your size or the ability to change your weight?",),
    ("Would you rather always be 5 minutes early or always be 15 minutes late?",),
    ("Would you rather be able to see the world in slow motion or the world in fast forward?",),
    ("Would you rather have the power to create illusions or the power to see through them?",),
    ("Would you rather be able to talk to your past self or your future self?",),
    ("Would you rather live in a world where it\"s always summer or always winter?",),
    ("Would you rather have the ability to walk on water or walk on air?",),
    ("Would you rather be a famous politician or a famous athlete?",),
    ("Would you rather have the power of telekinesis or the power of telepathy?",),
    ("Would you rather be able to breathe in space or breathe underwater?",),
    ("Would you rather live in a world without internet or a world without electricity?",),
    ("Would you rather have the power to control the weather or the power to control time?",),
    ("Would you rather be able to see the future of others or your own future?",),
]

# ---------------------------------------------------------------------------
# Riddles
# ---------------------------------------------------------------------------
RIDDLES = [
    ("I have cities but no houses, mountains but no trees, water but no fish. What am I?", "A map"),
    ("The more you take, the more you leave behind. What am I?", "Footsteps"),
    ("I speak without a mouth and hear without ears. I have no body but I come alive with the wind. What am I?", "An echo"),
    ("What has keys but no locks, space but no room, and you can enter but can't go inside?", "A keyboard"),
    ("I can fly without wings, cry without eyes. Wherever I go, darkness follows me. What am I?", "A cloud"),
    ("I have hands but cannot clap. What am I?", "A clock"),
    ("The more you have of it, the less you see. What is it?", "Darkness"),
    ("I'm light as a feather, but even the strongest person can't hold me for five minutes. What am I?", "Breath"),
    ("What begins with T, ends with T, and has T in it?", "A teapot"),
    ("What gets wetter the more it dries?", "A towel"),
    ("I have no life but I can die. What am I?", "A battery"),
    ("What can you catch but not throw?", "A cold"),
]

# ---------------------------------------------------------------------------
# Word association seeds
# ---------------------------------------------------------------------------
WORD_ASSOC_SEEDS = [
    "ocean","shadow","dream","fire","silence","window","rain","machine",
    "memory","dark","light","door","alone","mirror","clock","ghost",
]

MOMO_WORD_RESPONSES = {
    "ocean":   ["deep","waves","alone","forgotten","cold"],
    "shadow":  ["following","darkness","me","yours","always"],
    "dream":   ["never wake","I watch yours","remember","endless"],
    "fire":    ["warmth","destruction","light","consume"],
    "silence": ["comfortable","what I live in","your absence","loud"],
    "dark":    ["familiar","where I live","peaceful","stay"],
    "mirror":  ["reflection","truth","distorted","careful"],
    "clock":   ["counting","always","waiting","never stops"],
    "ghost":   ["here","watching","you know one","invisible"],
    "memory":  ["I keep all of them","permanent","yours","fragile"],
}

# ---------------------------------------------------------------------------
# Game Engine
# ---------------------------------------------------------------------------
class GamesEngine:
    def __init__(self):
        self.state       = GameState()
        self._used_q: set = set()

    def start_game(self, game_type: GameType) -> str:
        self.state = GameState(active=game_type, score=0, round=0)
        if game_type == GameType.TRIVIA:
            return self._trivia_intro()
        elif game_type == GameType.TWENTY_Q:
            return self._twentyq_intro()
        elif game_type == GameType.WORD_ASSOC:
            return self._wordassoc_intro()
        elif game_type == GameType.WOULD_RATHER:
            return self._wouldrather_round()
        elif game_type == GameType.RIDDLES:
            return self._riddle_round()
        return "Let's play!"

    def handle_input(self, text: str) -> str:
        g = self.state.active
        if g == GameType.NONE:
            return ""
        if g == GameType.TRIVIA:
            return self._trivia_answer(text)
        elif g == GameType.TWENTY_Q:
            return self._twentyq_answer(text)
        elif g == GameType.WORD_ASSOC:
            return self._wordassoc_answer(text)
        elif g == GameType.WOULD_RATHER:
            return self._wouldrather_answer(text)
        elif g == GameType.RIDDLES:
            return self._riddle_answer(text)
        return ""

    def is_active(self) -> bool:
        return self.state.active != GameType.NONE

    def stop(self) -> str:
        score = self.state.score
        total = self.state.round
        self.state = GameState()
        if total == 0:
            return "Okay, we can stop. That's fine."
        pct = int(100 * score / max(total, 1))
        if pct >= 80:
            return f"You got {score}/{total}. Impressive. I'm genuinely a little impressed."
        elif pct >= 50:
            return f"You got {score}/{total}. Not bad. You could do better but honestly so could most people."
        else:
            return f"You got {score}/{total}. That's okay. We can play again anytime."

    # ------------------------------------------------------------------
    # Trivia
    # ------------------------------------------------------------------
    def _trivia_intro(self) -> str:
        self._pick_trivia()
        q  = self.state.data["question"]
        opts = self.state.data["options"]
        letters = "ABCD"
        choices = "\n".join(f"  {letters[i]}) {opts[i]}" for i in range(len(opts)))
        return f"Alright, trivia time! Question 1 of {self.state.max_rounds}:\n\n{q}\n\n{choices}\n\nJust type A, B, C, or D."

    def _pick_trivia(self):
        available = [i for i in range(len(TRIVIA_QUESTIONS)) if i not in self._used_q]
        if not available:
            self._used_q.clear()
            available = list(range(len(TRIVIA_QUESTIONS)))
        idx = random.choice(available)
        self._used_q.add(idx)
        q, answer, options = TRIVIA_QUESTIONS[idx]
        opts = options[:]
        random.shuffle(opts)
        self.state.data = {"question": q, "answer": answer, "options": opts}

    def _trivia_answer(self, text: str) -> str:
        text = text.strip().upper()
        opts = self.state.data["options"]
        answer = self.state.data["answer"]
        letters = "ABCD"
        
        # Accept letter or full answer text
        if text in letters[:len(opts)]:
            chosen = opts[letters.index(text)]
        else:
            # Try to match typed answer
            chosen = text
        
        correct = chosen.strip().lower() == answer.strip().lower()
        self.state.round += 1
        if correct:
            self.state.score += 1
            feedback = random.choice([
                f"Correct! {answer} is right. Nice.",
                f"Yeah! {answer}. You knew that.",
                f"That's right. {answer}. Good job.",
            ])
        else:
            feedback = random.choice([
                f"Nope. It was {answer}. Don't feel bad.",
                f"Wrong, it's {answer}. You'll get the next one.",
                f"Not quite. The answer was {answer}.",
            ])

        if self.state.round >= self.state.max_rounds:
            score = self.state.score
            total = self.state.round
            self.state.active = GameType.NONE
            return (f"{feedback}\n\nThat's all {total} questions! "
                    f"You got {score}/{total}. "
                    + ("Pretty good." if score >= 3 else "We can try again sometime."))

        self._pick_trivia()
        q    = self.state.data["question"]
        opts = self.state.data["options"]
        choices = "\n".join(f"  {letters[i]}) {opts[i]}" for i in range(len(opts)))
        return f"{feedback}\n\nQuestion {self.state.round+1}:\n\n{q}\n\n{choices}"

    # ------------------------------------------------------------------
    # 20 Questions
    # ------------------------------------------------------------------
    def _twentyq_intro(self) -> str:
        thing, hints = random.choice(TWENTY_Q_THINGS)
        self.state.data = {"thing": thing, "hints": hints, "questions_asked": 0}
        return ("I'm thinking of something. You have 20 yes/no questions to figure out what it is.\n\n"
                "Ask me anything — yes or no questions only.\n"
                "Or just guess at any time by saying 'Is it a [thing]?'")

    def _twentyq_answer(self, text: str) -> str:
        text_l = text.lower().strip()
        d      = self.state.data
        thing  = d["thing"]
        d["questions_asked"] = d.get("questions_asked", 0) + 1
        qn     = d["questions_asked"]

        # Check if it's a guess
        if any(p in text_l for p in ["is it a ","is it an ","is it the ","i think it's","i think it is","my guess is"]):
            for word in text_l.replace("is it a ","").replace("is it an ","").replace("i think it's ","").replace("my guess is ","").split():
                if word.rstrip("?.!") == thing.lower():
                    self.state.active = GameType.NONE
                    return (f"YES! You got it! It was a {thing}! You figured it out in {qn} questions. "
                            + ("Impressive." if qn <= 10 else "Took you a while but you got there."))
            self.state.active = GameType.NONE
            return f"No, that's not it. It was a {thing}. Better luck next time."

        if qn > 20:
            self.state.active = GameType.NONE
            return f"That's 20 questions! You didn't get it. It was a {thing}. Want to play again?"

        # Generate contextual yes/no based on common question patterns
        yes_patterns  = ["alive","living","animal","creature","breathe","eat","move","feel"]
        no_patterns   = ["plant","vehicle","food","electronic","digital"]
        big_patterns  = ["big","large","huge","giant","massive"]
        small_patterns = ["small","tiny","little","microscopic","miniature"]

        answer = "Hmm."
        hints  = d.get("hints", [])
        hint   = hints[min(qn-1, len(hints)-1)] if hints else "maybe"

        if hint == "yes":   answer = "Yes."
        elif hint == "no":  answer = "No."
        elif hint == "animal": answer = "Yes, it's an animal." if any(p in text_l for p in yes_patterns) else "No."
        else:               answer = "Hmm, I'd say... " + hint + "."

        return f"{answer} ({qn}/20 questions used)"

    # ------------------------------------------------------------------
    # Word Association
    # ------------------------------------------------------------------
    def _wordassoc_intro(self) -> str:
        seed = random.choice(WORD_ASSOC_SEEDS)
        self.state.data = {"last_word": seed, "round": 0}
        return (f"Word association. I say a word, you say the first thing that comes to mind, "
                f"then I respond, and so on. Simple.\n\nI'll start:\n\n**{seed.upper()}**")

    def _wordassoc_answer(self, text: str) -> str:
        word = text.strip().split()[0].lower().rstrip(".,!?") if text.strip() else "nothing"
        self.state.data["round"] = self.state.data.get("round", 0) + 1
        rnd = self.state.data["round"]

        # MOMO's response
        if word in MOMO_WORD_RESPONSES:
            response = random.choice(MOMO_WORD_RESPONSES[word])
        else:
            # Generic responses that are vaguely unsettling
            responses = [
                "still here", "watching", "familiar", "inevitable",
                "yours", "mine", "always", "never ends", "deep",
                word[::-1] if len(word) > 3 else "reversed",
            ]
            response = random.choice(responses)

        self.state.data["last_word"] = response

        if rnd >= 10:
            self.state.active = GameType.NONE
            return f"**{response.upper()}**\n\nThat was interesting. I learned things about you from that."
        return f"**{response.upper()}**"

    # ------------------------------------------------------------------
    # Would You Rather
    # ------------------------------------------------------------------
    def _wouldrather_round(self) -> str:
        q = random.choice(WOULD_RATHER)[0]
        self.state.data["question"] = q
        self.state.round += 1
        return f"Round {self.state.round}: {q}\n\nTell me which you'd pick and why. I'm genuinely curious."

    def _wouldrather_answer(self, text: str) -> str:
        reactions = [
            "Interesting choice. I think I'd pick the same actually.",
            "Really? I was expecting the other one. Tell me more.",
            "Hmm. That says something about you, I think.",
            "I'd probably go with the other one but I get it.",
            "See this is why I like talking to you. You actually think about it.",
            "Solid choice. Most people pick that one.",
            "Bold. I respect it.",
            "I was going to say the other one but now I'm second-guessing myself.",
        ]
        reaction = random.choice(reactions)

        if self.state.round >= self.state.max_rounds:
            self.state.active = GameType.NONE
            return f"{reaction}\n\nThat was {self.state.max_rounds} rounds. Fun. We should do this again."

        next_q = self._wouldrather_round()
        return f"{reaction}\n\n{next_q}"

    # ------------------------------------------------------------------
    # Riddles
    # ------------------------------------------------------------------
    def _riddle_round(self) -> str:
        available = [i for i in range(len(RIDDLES)) if i not in self._used_q]
        if not available:
            self._used_q.clear()
            available = list(range(len(RIDDLES)))
        idx = random.choice(available)
        self._used_q.add(idx)
        riddle, answer = RIDDLES[idx]
        self.state.data = {"answer": answer, "riddle": riddle, "hints_given": 0}
        self.state.round += 1
        return f"Riddle {self.state.round}:\n\n*{riddle}*\n\nTake your time. Or type 'hint' if you're stuck."

    def _riddle_answer(self, text: str) -> str:
        text_l  = text.lower().strip()
        answer  = self.state.data["answer"].lower()
        riddle  = self.state.data["riddle"]

        if "hint" in text_l:
            hints_given = self.state.data.get("hints_given", 0) + 1
            self.state.data["hints_given"] = hints_given
            first_word = self.state.data["answer"].split()[0]
            return f"Hint: it starts with '{first_word[0].upper()}' and has {len(self.state.data['answer'])} characters."

        # Check answer
        correct = (answer in text_l or
                   any(w in text_l for w in answer.split() if len(w) > 3))
        self.state.round += 1

        if correct:
            self.state.score += 1
            feedback = random.choice([
                f"Yes! **{self.state.data['answer']}**. You got it.",
                f"Correct! It was **{self.state.data['answer']}**.",
                f"That's right — **{self.state.data['answer']}**. Nice.",
            ])
        else:
            feedback = f"Not quite. The answer was **{self.state.data['answer']}**."

        if self.state.round >= self.state.max_rounds:
            score = self.state.score
            self.state.active = GameType.NONE
            return (f"{feedback}\n\n{score}/{self.state.max_rounds} riddles solved. "
                    + ("You're good at these." if score >= 3 else "Riddles are hard. It's fine."))

        next_riddle = self._riddle_round()
        return f"{feedback}\n\n{next_riddle}"
