from pathlib import Path

BASE_DIR    = Path(__file__).parent
ASSETS_DIR  = BASE_DIR / "assets"
SPRITES_DIR = ASSETS_DIR / "sprites"
DB_PATH     = BASE_DIR / "data" / "companion.db"

COMPANION_NAME      = "MOMO"
WINDOW_WIDTH        = 150
WINDOW_HEIGHT       = 200
ANIMATION_FPS       = 8
BLINK_INTERVAL_MS   = 4500

ANTHROPIC_MODEL     = ""          # unused, no API
MAX_TOKENS          = 0
MAX_CONTEXT_MESSAGES = 12

TYPEWRITER_BASE_MS  = 28          # base delay per char
TYPEWRITER_JITTER   = 12          # random ± added per char
TYPEWRITER_PAUSE_MS = 180         # extra pause after punctuation

# TTS Voice selection (Windows only)
# Run: python list_voices.py  (to see available voices and indices)
# 0 = female default, 1 = male (BonziBuddy-like), 2+ = other voices
TTS_VOICE_INDEX     = 2
TTS_VOICE_PITCH     = 140      # Pitch level (0-255, typical 50-200)
TTS_VOICE_SPEED     = 157      # Speech speed (typical 50-200, higher = faster)

LONELY_THRESHOLD_S              = 3600
ANGRY_CLOSE_THRESHOLD           = 3
MANIPULATIVE_SESSION_THRESHOLD  = 5
FAMILIARITY_MESSAGE_THRESHOLD   = 15

HORROR_BASE_PROBABILITY     = 5
HORROR_COOLDOWN_S           = 100
HORROR_SESSION_MILESTONES   = {6, 13, 20, 33}

SHAKE_ITERATIONS    = 20
SHAKE_AMPLITUDE_PX  = 9
SHAKE_INTERVAL_MS   = 32
GLITCH_FLASH_MS     = 90
POPUP_DISPLAY_MS    = 5000
CHAT_WIDTH          = 400
CHAT_HEIGHT         = 480
