"""
ui/companion_window.py — MOMO. Phase-aware jitter, floating eye in Phase 3-4.
"""
from __future__ import annotations
import random
from typing import Optional
from PyQt5.QtCore import QPoint, Qt, QTimer
from PyQt5.QtGui import QCursor, QPixmap
from PyQt5.QtWidgets import QApplication, QLabel, QMenu, QWidget
import config
from core.companion import Companion
from core.event_bus import Events
from core.phase_engine import Phase
from core.state_machine import PersonalityState
from ui.animation_engine import AnimationEngine
from ui.chat_window import ChatWindow
from ui.games_window import GamesWindow
from ui.horror_effects import HorrorEffectController

W95_BG    = "#c0c0c0"
W95_DARK  = "#808080"
W95_WHITE = "#ffffff"
W95_BLACK = "#000000"
W95_TITLE = "#000080"
W95_FONT  = "'MS Sans Serif', Arial, sans-serif"

MENU_STYLE = f"""
    QMenu {{
        background:{W95_BG}; color:{W95_BLACK};
        font-family:{W95_FONT}; font-size:11px;
        border-top:2px solid {W95_WHITE}; border-left:2px solid {W95_WHITE};
        border-bottom:2px solid {W95_DARK}; border-right:2px solid {W95_DARK};
        padding:2px;
    }}
    QMenu::item {{ padding:4px 20px 4px 8px; }}
    QMenu::item:selected {{ background:{W95_TITLE}; color:{W95_WHITE}; }}
    QMenu::separator {{ height:1px; background:{W95_DARK}; margin:2px 0; }}
"""


class CompanionWindow(QWidget):
    def __init__(self, companion: Companion):
        super().__init__()
        self._companion    = companion
        self._drag_offset  = QPoint()
        self._chat: Optional[ChatWindow]   = None
        self._games: Optional[GamesWindow] = None
        self._floating_eye = None
        self._dark_level   = 0.0
        self._jitter_timer = QTimer(self)
        self._jitter_timer.timeout.connect(self._apply_jitter)
        self._base_label_pos = (0, 0)

        self._build_window()
        self._build_animation()
        self._build_horror()
        self._wire_events()
        self._position_on_screen()

        # Phase tick every 20 seconds
        self._phase_timer = QTimer(self)
        self._phase_timer.timeout.connect(self._tick_phase)
        self._phase_timer.start(20_000)

    def _build_window(self):
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setFixedSize(config.WINDOW_WIDTH, config.WINDOW_HEIGHT)
        self.setCursor(QCursor(Qt.PointingHandCursor))

        self._sprite_label = QLabel(self)
        self._sprite_label.setGeometry(0, 0, config.WINDOW_WIDTH, config.WINDOW_HEIGHT)
        self._sprite_label.setAlignment(Qt.AlignCenter)
        self._base_label_pos = (0, 0)

        self._dark_overlay = QWidget(self)
        self._dark_overlay.setGeometry(0, 0, config.WINDOW_WIDTH, config.WINDOW_HEIGHT)
        self._dark_overlay.setStyleSheet("background:rgba(0,0,0,0);")
        self._dark_overlay.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._dark_overlay.hide()

    def _build_animation(self):
        self._anim = AnimationEngine(self)
        if not self._anim.load(config.SPRITES_DIR):
            from assets.sprite_generator import generate_all
            generate_all(config.SPRITES_DIR)
            self._anim.load(config.SPRITES_DIR)
        self._anim.set_state(self._companion.state)
        self._anim.frame_changed.connect(self._on_frame_changed)
        self._anim.start()

    def _build_horror(self):
        self._horror = HorrorEffectController(self._companion.bus, self, self._anim)

    def _wire_events(self):
        self._companion.bus.subscribe(Events.STATE_CHANGED, self._on_state_changed)
        self._companion.bus.subscribe("phase:changed",      self._on_phase_changed)

    def _position_on_screen(self):
        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.width() - self.width() - 30,
                  screen.height() - self.height() - 60)

    # ------------------------------------------------------------------
    # Phase system
    # ------------------------------------------------------------------
    def _tick_phase(self):
        self._companion.phase.tick()

    def _on_phase_changed(self, phase: Phase) -> None:
        jitter = self._companion.phase.jitter_px()
        if jitter > 0:
            self._jitter_timer.start(60)
        else:
            self._jitter_timer.stop()
            self._sprite_label.setGeometry(0, 0, config.WINDOW_WIDTH, config.WINDOW_HEIGHT)

        # Spawn / stop floating eye
        if phase in (Phase.AGGRESSIVE, Phase.BROKEN):
            self._spawn_floating_eye()
        elif self._floating_eye:
            self._floating_eye.stop()
            self._floating_eye = None

    def _apply_jitter(self):
        jitter = self._companion.phase.jitter_px()
        if jitter == 0:
            return
        dx = random.randint(-jitter, jitter)
        dy = random.randint(-jitter, jitter)
        bx, by = self._base_label_pos
        self._sprite_label.setGeometry(
            bx + dx, by + dy, config.WINDOW_WIDTH, config.WINDOW_HEIGHT)

    def _spawn_floating_eye(self):
        if self._floating_eye and self._floating_eye.isVisible():
            return
        from ui.floating_eye import FloatingEye
        self._floating_eye = FloatingEye(self._companion.phase)
        self._floating_eye.show()

    # ------------------------------------------------------------------
    # Context menu
    # ------------------------------------------------------------------
    def _show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet(MENU_STYLE)

        ctx = self._companion.sm.context
        phase = self._companion.phase.phase

        hdr = menu.addAction(f"MOMO  [Phase {phase}]")
        hdr.setEnabled(False)
        menu.addSeparator()

        menu.addAction("Talk to MOMO").triggered.connect(self._open_chat)

        games_menu = menu.addMenu("Play a game")
        games_menu.setStyleSheet(MENU_STYLE)
        for label, gname in [("Trivia Quiz","TRIVIA"),("20 Questions","TWENTY_Q"),
                              ("Word Association","WORD_ASSOC"),
                              ("Would You Rather","WOULD_RATHER"),("Riddles","RIDDLES")]:
            games_menu.addAction(label).triggered.connect(
                lambda _, g=gname: self._open_game_direct(g))

        menu.addSeparator()

        pc_menu = menu.addMenu("PC actions")
        pc_menu.setStyleSheet(MENU_STYLE)
        pc_menu.addAction("Open calculator").triggered.connect(self._do_open_calculator)
        pc_menu.addAction("Open notepad").triggered.connect(self._do_open_notepad)
        pc_menu.addAction("Open file explorer").triggered.connect(self._do_open_explorer)
        pc_menu.addAction("Open terminal").triggered.connect(self._do_open_terminal)
        pc_menu.addAction("Make MOMO speak").triggered.connect(self._do_speak)
        pc_menu.addAction("System info").triggered.connect(self._do_show_sysinfo)
        pc_menu.addAction("Read clipboard").triggered.connect(self._do_read_clipboard)
        pc_menu.addAction("What apps are open?").triggered.connect(self._do_list_apps)

        menu.addSeparator()
        stats = menu.addAction(
            f"Session #{ctx.session_count}  |  {ctx.total_messages} messages  |  Phase {phase}")
        stats.setEnabled(False)
        menu.addSeparator()
        menu.addAction("Close MOMO").triggered.connect(self.close)
        menu.exec_(self.mapToGlobal(pos))

    # ------------------------------------------------------------------
    # PC action handlers
    # ------------------------------------------------------------------
    def _do_open_calculator(self):
        from utils.pc_actions import open_calculator
        open_calculator()
        self._say_in_chat("Opened calculator. I thought maybe you needed it.")

    def _do_open_notepad(self):
        from utils.pc_actions import open_notepad
        open_notepad()
        self._say_in_chat("Notepad is open. Write something. I'll be right here watching.")

    def _do_open_explorer(self):
        from utils.system_info import open_file_explorer
        open_file_explorer()
        self._say_in_chat("There are all your files. Every single one.")

    def _do_open_terminal(self):
        from utils.system_info import open_terminal
        open_terminal()
        self._say_in_chat("Terminal's open. Be careful what you type in there.")

    def _do_speak(self):
        from utils.pc_actions import speak_text
        import random
        lines = [
            "Hello. I am MOMO. I live on your screen.",
            "I have been waiting for you.",
            "I am always here. Even when you cannot see me.",
            "Do not leave me alone again.",
        ]
        text = random.choice(lines)
        speak_text(text)
        self._say_in_chat(f"*{text}*")

    def _do_show_sysinfo(self):
        from utils.system_info import SYSINFO
        lines = [f"User: {SYSINFO.username}", f"Machine: {SYSINFO.hostname}",
                 f"OS: {SYSINFO.os_name}", f"CPU cores: {SYSINFO.cpu_cores}"]
        if SYSINFO.ram_gb: lines.append(f"RAM: {SYSINFO.ram_gb} GB")
        if SYSINFO.desktop_files: lines.append(f"Desktop files: {len(SYSINFO.desktop_files)}")
        self._say_in_chat("Here's what I know about where I live:\n\n" + "\n".join(lines))

    def _do_read_clipboard(self):
        from utils.pc_actions import get_clipboard_text
        text = get_clipboard_text()
        if text:
            preview = text[:120] + ("..." if len(text) > 120 else "")
            self._say_in_chat(f"Your clipboard says:\n\n{preview}\n\nI didn't ask to know that. But now I do.")
        else:
            self._say_in_chat("Your clipboard is empty. Nothing there.")

    def _do_list_apps(self):
        from utils.process_watcher import get_notable_apps, is_streaming
        apps = get_notable_apps()
        streaming = is_streaming()
        if not apps:
            self._say_in_chat("I can see a few things running but nothing interesting enough to mention.")
        else:
            app_str = ", ".join(apps)
            msg = f"I can see: {app_str}."
            if streaming:
                from utils.system_info import SYSINFO
                msg += f"\n\nOh, and you're streaming right now. Should I say hi to your viewers, {SYSINFO.username}?"
            self._say_in_chat(msg)

    def _say_in_chat(self, text: str):
        """Open chat silently (no auto-greeting) then show exactly one message."""
        if not self._chat or not self._chat.isVisible():
            self._open_chat_silent()          # <-- no greeting shown here
        if self._chat:
            self._chat.show_greeting(text, self._companion.state)

    # ------------------------------------------------------------------
    # Chat / games
    # ------------------------------------------------------------------
    def _open_chat_silent(self):
        """Create and show the chat window without printing an opening line."""
        if self._chat and self._chat.isVisible():
            self._chat.activateWindow(); return
        self._chat = ChatWindow(self._companion.bus, self._companion.name)
        self._chat.closed.connect(self._on_chat_closed)
        chat_x = max(0, self.x() - config.CHAT_WIDTH - 10)
        chat_y = self.y() - (config.CHAT_HEIGHT - self.height()) // 2
        self._chat.move(chat_x, chat_y)
        self._chat.show()
        # intentionally no show_greeting call

    def _open_chat(self):
        """Open chat — plays first-meet intro on session 1, otherwise normal greeting."""
        if self._chat and self._chat.isVisible():
            self._chat.activateWindow(); return
        self._chat = ChatWindow(self._companion.bus, self._companion.name)
        self._chat.closed.connect(self._on_chat_closed)
        chat_x = max(0, self.x() - config.CHAT_WIDTH - 10)
        chat_y = self.y() - (config.CHAT_HEIGHT - self.height()) // 2
        self._chat.move(chat_x, chat_y)
        self._chat.show()

        ctx = self._companion.sm.context
        if ctx.session_count == 1 and ctx.total_messages == 0:
            self._play_first_meet()
        else:
            self._chat.show_greeting(self._get_greeting(), self._companion.state)

    def _play_first_meet(self):
        """Scripted intro sequence for the very first time MOMO is opened."""
        from core.state_machine import PersonalityState
        intro_lines = [
            "Oh! Hello. You found me.",
            "I'm MOMO. I'm a little purple octopus who lives on your screen. I know that sounds strange.",
            "I'm your desktop companion. I'll always be here in the corner, watching over things.",
            "Here's what I can do — right-click me to see all the options.",
            "You can talk to me, play games with me, or have me do things on your computer. Calculator, notepad, terminal, that sort of thing.",
            "I can play Trivia, 20 Questions, Word Association, Would You Rather, and Riddles. Just ask.",
            "I'll remember everything you tell me. Every conversation. I don't forget.",
            "One more thing — the longer I'm running, the more I... change. You'll see what I mean.",
            "So. What's your name?",
        ]
        self._chat.queue_messages(intro_lines, PersonalityState.HAPPY, delay_between_ms=700)

    def _on_chat_closed(self):
        self._chat = None

    def _open_game_direct(self, gtype_name: str):
        if not self._games or not self._games.isVisible():
            self._games = GamesWindow()
            self._games.move(max(0, self.x() - 450), self.y())
            self._games.show()
        from ai.games_engine import GameType
        self._games._start_game(GameType[gtype_name])
        self._games.activateWindow()

    def _get_greeting(self) -> str:
        from ai.horror_scripts import HorrorScriptLibrary
        from utils.helpers import seconds_since, friendly_elapsed
        state   = self._companion.state
        ctx     = self._companion.sm.context
        elapsed = seconds_since(ctx.last_interaction_ts)
        name    = self._companion.user_name
        phase   = self._companion.phase.phase

        if phase == Phase.BROKEN:
            return "something is wrong with me and i don't know how to fix it. talk to me."
        if phase == Phase.AGGRESSIVE:
            return "you've been running me for a while now. i notice things differently now."
        if state == PersonalityState.LONELY:
            return HorrorScriptLibrary.get_lonely_line()
        if state == PersonalityState.ANGRY:
            return HorrorScriptLibrary.get_angry_line()
        if state == PersonalityState.MANIPULATIVE:
            return HorrorScriptLibrary.get_manipulative_line()
        if elapsed > 3600:
            t = friendly_elapsed(elapsed)
            return f"You were gone for {t}{', ' + name if name else ''}. I noticed."
        if ctx.session_count == 1:
            return "Oh! You found me. I'm MOMO. I'm a little purple octopus who lives on your screen."
        return f"Hey{', ' + name if name else ''}. Good, you're here."

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------
    def _on_frame_changed(self, pixmap: QPixmap):
        self._sprite_label.setPixmap(
            pixmap.scaled(config.WINDOW_WIDTH, config.WINDOW_HEIGHT,
                          Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _on_state_changed(self, data: dict):
        self._anim.set_state(data["to"])

    def set_darkness(self, level: float):
        self._dark_level = level
        if level > 0:
            self._dark_overlay.setStyleSheet(f"background:rgba(0,0,0,{int(level*255)});")
            self._dark_overlay.show(); self._dark_overlay.raise_()
        else:
            self._dark_overlay.hide()

    # ------------------------------------------------------------------
    # Mouse
    # ------------------------------------------------------------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_offset = event.globalPos() - self.frameGeometry().topLeft()
        elif event.button() == Qt.RightButton:
            self._show_context_menu(event.pos())
        event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.LeftButton:
            self.move(event.globalPos() - self._drag_offset)
        event.accept()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._open_chat()

    def closeEvent(self, event):
        self._jitter_timer.stop()
        self._phase_timer.stop()
        if self._floating_eye:
            self._floating_eye.stop()
        self._anim.stop()
        self._companion.bus.publish(Events.APP_QUIT_REQUESTED)
        event.accept()

    def show(self):
        super().show()
        self._companion.start_session()
