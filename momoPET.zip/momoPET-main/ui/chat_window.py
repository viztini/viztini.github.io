"""
ui/chat_window.py — Win95 chat window.
Changes: auto-speaks every MOMO line, supports queued message sequences.
"""
from __future__ import annotations
import random
from PyQt5.QtCore import Qt, QTimer, QPoint, pyqtSignal
from PyQt5.QtGui import QTextCursor
from PyQt5.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTextEdit, QVBoxLayout, QWidget
)
import config
from core.event_bus import EventBus, Events
from core.state_machine import PersonalityState

W95_BG    = "#c0c0c0"
W95_DARK  = "#808080"
W95_WHITE = "#ffffff"
W95_BLACK = "#000000"
W95_TITLE = "#000080"
W95_MOMO  = "#7b2fbe"
W95_FONT  = "'MS Sans Serif', 'Arial', sans-serif"

_STATE_COLORS = {
    PersonalityState.HAPPY:        W95_MOMO,
    PersonalityState.LONELY:       "#4040a0",
    PersonalityState.ANGRY:        "#a02020",
    PersonalityState.MANIPULATIVE: "#6a0dad",
}

WIN95_BTN = f"""
    QPushButton {{
        background:{W95_BG}; color:{W95_BLACK};
        font-family:{W95_FONT}; font-size:11px;
        border-top:2px solid {W95_WHITE}; border-left:2px solid {W95_WHITE};
        border-bottom:2px solid {W95_DARK}; border-right:2px solid {W95_DARK};
        padding:2px 8px; min-height:20px;
    }}
    QPushButton:pressed {{
        border-top:2px solid {W95_DARK}; border-left:2px solid {W95_DARK};
        border-bottom:2px solid {W95_WHITE}; border-right:2px solid {W95_WHITE};
    }}
"""


class TitleBar(QWidget):
    def __init__(self, title: str, on_close, parent=None):
        super().__init__(parent)
        self.setFixedHeight(22)
        self.setStyleSheet(f"background:{W95_TITLE};")
        self._drag_pos    = None
        self._parent_win  = parent
        lay = QHBoxLayout(self)
        lay.setContentsMargins(3, 2, 2, 2); lay.setSpacing(0)
        ico = QLabel("🐙"); ico.setStyleSheet("color:white;font-size:12px;background:transparent;"); ico.setFixedWidth(18)
        lbl = QLabel(f" {title}"); lbl.setStyleSheet(f"color:{W95_WHITE};font-family:{W95_FONT};font-size:11px;font-weight:bold;background:transparent;")
        cbtn = QPushButton("✕"); cbtn.setFixedSize(18, 16)
        cbtn.setStyleSheet(f"background:{W95_BG};color:{W95_BLACK};font-size:9px;font-weight:bold;border-top:2px solid {W95_WHITE};border-left:2px solid {W95_WHITE};border-bottom:2px solid {W95_DARK};border-right:2px solid {W95_DARK};padding:0;")
        cbtn.clicked.connect(on_close)
        lay.addWidget(ico); lay.addWidget(lbl, stretch=1); lay.addWidget(cbtn)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag_pos = e.globalPos() - self._parent_win.frameGeometry().topLeft()
    def mouseMoveEvent(self, e):
        if e.buttons() & Qt.LeftButton and self._drag_pos:
            self._parent_win.move(e.globalPos() - self._drag_pos)
    def mouseReleaseEvent(self, e): self._drag_pos = None


class ChatWindow(QWidget):
    closed = pyqtSignal()

    def __init__(self, bus: EventBus, companion_name: str, parent=None):
        super().__init__(parent)
        self._bus           = bus
        self._name          = companion_name
        self._thinking      = False

        # Typewriter state
        self._tw_timer      = QTimer(self)
        self._tw_timer.timeout.connect(self._tw_tick)
        self._tw_text       = ""
        self._tw_full_text  = ""   # full text stored for TTS
        self._tw_color      = W95_MOMO
        self._tw_index      = 0

        # Message queue for intro sequences
        self._msg_queue:  list[tuple[str, PersonalityState]] = []
        self._queue_delay = 600

        self._build_ui()
        self._wire_events()

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------
    def _build_ui(self):
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setFixedSize(config.CHAT_WIDTH, config.CHAT_HEIGHT)

        outer = QWidget(self)
        outer.setGeometry(0, 0, config.CHAT_WIDTH, config.CHAT_HEIGHT)
        outer.setStyleSheet(
            f"background:{W95_BG};"
            f"border-top:2px solid {W95_WHITE};border-left:2px solid {W95_WHITE};"
            f"border-bottom:2px solid {W95_DARK};border-right:2px solid {W95_DARK};")

        layout = QVBoxLayout(outer)
        layout.setContentsMargins(4, 4, 4, 6); layout.setSpacing(4)

        self._titlebar = TitleBar(self._name, self.close, parent=self)
        layout.addWidget(self._titlebar)

        menu_bar = QLabel("  File    View    Help")
        menu_bar.setStyleSheet(f"background:{W95_BG};color:{W95_BLACK};font-family:{W95_FONT};font-size:11px;padding:1px 0;")
        layout.addWidget(menu_bar)

        self._log = QTextEdit(); self._log.setReadOnly(True)
        self._log.setStyleSheet(f"""
            QTextEdit {{
                background:{W95_WHITE}; color:{W95_BLACK};
                font-family:'Courier New',monospace; font-size:12px;
                border-top:2px solid {W95_DARK}; border-left:2px solid {W95_DARK};
                border-bottom:2px solid {W95_WHITE}; border-right:2px solid {W95_WHITE};
                padding:4px;
            }}
            QScrollBar:vertical {{ background:{W95_BG}; width:16px; }}
            QScrollBar::handle:vertical {{
                background:{W95_BG};
                border-top:2px solid {W95_WHITE}; border-left:2px solid {W95_WHITE};
                border-bottom:2px solid {W95_DARK}; border-right:2px solid {W95_DARK};
                min-height:20px;
            }}
        """)
        layout.addWidget(self._log, stretch=1)

        self._status = QLabel("Ready")
        self._status.setStyleSheet(
            f"background:{W95_BG};color:{W95_BLACK};font-family:{W95_FONT};font-size:11px;"
            f"border-top:1px solid {W95_DARK};padding:1px 4px;")
        layout.addWidget(self._status)

        row = QHBoxLayout(); row.setSpacing(4)
        lbl = QLabel("Say:"); lbl.setStyleSheet(f"color:{W95_BLACK};font-family:{W95_FONT};font-size:11px;")
        self._input = QLineEdit()
        self._input.setStyleSheet(
            f"background:{W95_WHITE};color:{W95_BLACK};font-family:{W95_FONT};font-size:12px;"
            f"border-top:2px solid {W95_DARK};border-left:2px solid {W95_DARK};"
            f"border-bottom:2px solid {W95_WHITE};border-right:2px solid {W95_WHITE};padding:2px 4px;")
        self._input.returnPressed.connect(self._on_submit)
        send_btn = QPushButton("Send"); send_btn.setStyleSheet(WIN95_BTN)
        send_btn.clicked.connect(self._on_submit)
        row.addWidget(lbl); row.addWidget(self._input, stretch=1); row.addWidget(send_btn)
        layout.addLayout(row)
        self._input.setFocus()

    def _wire_events(self):
        self._bus.subscribe(Events.CHAT_RESPONSE_READY, self._on_response)
        self._bus.subscribe(Events.CHAT_ERROR,          self._on_error)
        self._bus.subscribe(Events.STATE_CHANGED,       self._on_state_change)

    # ------------------------------------------------------------------
    # Input / submit
    # ------------------------------------------------------------------
    def _on_submit(self):
        text = self._input.text().strip()
        if not text or self._thinking or self._tw_timer.isActive():
            return
        self._input.clear()
        self._input.setEnabled(False)
        self._append_instant("You", text, "#000060")
        self._thinking = True
        self._status.setText("MOMO is typing...")
        self._bus.publish(Events.CHAT_USER_MESSAGE, text)

    def _on_response(self, data: dict):
        text  = data["text"]
        state = data["state"]
        color = _STATE_COLORS.get(state, W95_MOMO)
        self._start_typewriter(self._name, text, color)

    def _on_error(self, msg: str):
        self._thinking = False
        self._input.setEnabled(True)
        self._append_instant("ERROR", msg, "#cc0000")
        self._status.setText("Ready")

    def _on_state_change(self, data: dict):
        self._append_system(f"[Mood: {data['to'].value}]")

    # ------------------------------------------------------------------
    # Typewriter
    # ------------------------------------------------------------------
    def _start_typewriter(self, sender: str, text: str, color: str):
        self._append_sender_label(sender, color)
        self._tw_text      = text
        self._tw_full_text = text          # keep full copy for TTS
        self._tw_color     = color
        self._tw_index     = 0
        self._input.setEnabled(False)
        self._tw_timer.start(config.TYPEWRITER_BASE_MS)

    def _tw_tick(self):
        if self._tw_index >= len(self._tw_text):
            # --- Done ---
            self._tw_timer.stop()
            self._append_raw("<br>")
            self._thinking = False
            self._input.setEnabled(True)
            self._input.setFocus()
            self._status.setText("Ready")

            # Auto-speak every MOMO line
            self._speak_line(self._tw_full_text)

            # Advance queue if any
            if self._msg_queue:
                next_text, next_state = self._msg_queue.pop(0)
                QTimer.singleShot(
                    self._queue_delay,
                    lambda t=next_text, s=next_state: self.show_greeting(t, s)
                )
            return

        ch = self._tw_text[self._tw_index]; self._tw_index += 1
        esc = (ch.replace("&","&amp;").replace("<","&lt;")
                 .replace(">","&gt;").replace(" ","&nbsp;").replace("\n","<br>"))
        self._append_raw(f'<span style="color:{self._tw_color};">{esc}</span>')

        delay = config.TYPEWRITER_BASE_MS + random.randint(
            -config.TYPEWRITER_JITTER, config.TYPEWRITER_JITTER)
        if ch in ".!?":   delay += config.TYPEWRITER_PAUSE_MS
        elif ch in ",;:": delay += config.TYPEWRITER_PAUSE_MS // 3
        self._tw_timer.setInterval(max(8, delay))

    # ------------------------------------------------------------------
    # Auto-speak
    # ------------------------------------------------------------------
    @staticmethod
    def _speak_line(text: str):
        """Speak a MOMO line aloud using OS TTS. Non-blocking."""
        try:
            from utils.pc_actions import speak_text
            # Strip markdown, game formatting etc.
            clean = (text.replace("*","").replace("_","")
                        .replace("**","").replace("\n"," ")
                        .replace("&nbsp;"," ").strip())
            if clean:
                # Use voice settings from config
                voice_idx = getattr(config, 'TTS_VOICE_INDEX', 2)
                voice_pitch = getattr(config, 'TTS_VOICE_PITCH', 140)
                voice_speed = getattr(config, 'TTS_VOICE_SPEED', 157)
                speak_text(clean, voice_index=voice_idx, pitch=voice_pitch, speed=voice_speed)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Queued message sequences (for first-meet intro)
    # ------------------------------------------------------------------
    def queue_messages(self, messages: list[str], state: PersonalityState,
                       delay_between_ms: int = 600):
        """
        Show a sequence of MOMO messages one after another,
        waiting for each typewriter to finish before starting the next.
        The first message starts immediately; the rest are queued.
        """
        if not messages:
            return
        self._queue_delay = delay_between_ms
        self._msg_queue   = [(m, state) for m in messages[1:]]
        self.show_greeting(messages[0], state)

    # ------------------------------------------------------------------
    # Log helpers
    # ------------------------------------------------------------------
    def _append_sender_label(self, sender: str, color: str):
        self._append_raw(
            f'<span style="color:{color};font-weight:bold;">[{sender}]</span> ')

    def _append_instant(self, sender: str, text: str, color: str):
        esc = (text.replace("&","&amp;").replace("<","&lt;")
                   .replace(">","&gt;").replace(" ","&nbsp;").replace("\n","<br>"))
        self._append_raw(
            f'<span style="color:{color};font-weight:bold;">[{sender}]</span> '
            f'<span style="color:{W95_BLACK};">{esc}</span><br>')

    def _append_system(self, text: str):
        esc = text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
        self._append_raw(f'<span style="color:{W95_DARK};font-size:10px;">{esc}</span><br>')

    def _append_raw(self, html: str):
        cur = self._log.textCursor()
        cur.movePosition(QTextCursor.End)
        cur.insertHtml(html)
        self._log.verticalScrollBar().setValue(self._log.verticalScrollBar().maximum())

    def show_greeting(self, text: str, state: PersonalityState):
        color = _STATE_COLORS.get(state, W95_MOMO)
        self._start_typewriter(self._name, text, color)

    def closeEvent(self, event):
        self._tw_timer.stop()
        self._thinking = False
        self._msg_queue.clear()
        self.closed.emit()
        event.accept()
