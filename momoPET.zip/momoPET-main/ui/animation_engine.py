"""
ui/animation_engine.py
-----------------------
Loads PNG sprite frames from disk and provides frame-cycling logic.
Communicates with the companion window via Qt signals.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PyQt5.QtCore import QObject, QTimer, pyqtSignal
from PyQt5.QtGui import QPixmap

import config
from core.state_machine import PersonalityState


class AnimationEngine(QObject):
    """
    Manages per-state sprite frame sequences and fires a signal
    whenever the displayed frame should change.
    """

    frame_changed = pyqtSignal(QPixmap)   # emitted on each tick

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._frames: dict[str, list[QPixmap]] = {}
        self._glitch_frames: list[QPixmap] = []
        self._current_state = PersonalityState.HAPPY
        self._frame_idx     = 0
        self._glitching     = False
        self._glitch_idx    = 0

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

        self._loaded = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self, sprites_dir: Path) -> bool:
        """Load all sprite frames from *sprites_dir*. Returns True on success."""
        success = True
        for state in PersonalityState:
            state_dir = sprites_dir / state.value
            frames = self._load_state_frames(state_dir)
            if frames:
                self._frames[state.value] = frames
            else:
                success = False

        glitch_dir = sprites_dir / "glitch"
        self._glitch_frames = self._load_state_frames(glitch_dir)

        self._loaded = bool(self._frames)
        return success

    def start(self) -> None:
        interval_ms = 1000 // config.ANIMATION_FPS
        self._timer.start(interval_ms)

    def stop(self) -> None:
        self._timer.stop()

    def set_state(self, state: PersonalityState) -> None:
        if state != self._current_state:
            self._current_state = state
            self._frame_idx     = 0

    def trigger_glitch(self, duration_ms: int = 800) -> None:
        """Flash the glitch overlay for *duration_ms* milliseconds."""
        self._glitching  = True
        self._glitch_idx = 0
        QTimer.singleShot(duration_ms, self._stop_glitch)

    def current_pixmap(self) -> Optional[QPixmap]:
        frames = self._frames.get(self._current_state.value, [])
        if not frames:
            return None
        return frames[self._frame_idx % len(frames)]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _tick(self) -> None:
        if not self._loaded:
            return

        if self._glitching and self._glitch_frames:
            pm = self._glitch_frames[self._glitch_idx % len(self._glitch_frames)]
            self._glitch_idx += 1
        else:
            frames = self._frames.get(self._current_state.value, [])
            if not frames:
                return
            self._frame_idx = (self._frame_idx + 1) % len(frames)
            pm = frames[self._frame_idx]

        self.frame_changed.emit(pm)

    def _stop_glitch(self) -> None:
        self._glitching = False

    @staticmethod
    def _load_state_frames(directory: Path) -> list[QPixmap]:
        frames = []
        if not directory.exists():
            return frames
        for i in range(config.ANIMATION_FPS + 4):   # try up to N frames
            path = directory / f"frame_{i}.png"
            if not path.exists():
                break
            pm = QPixmap(str(path))
            if not pm.isNull():
                frames.append(pm)
        return frames
