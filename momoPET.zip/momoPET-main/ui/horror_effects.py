"""
ui/horror_effects.py — Horror effects, Win95-style popups, phase-aware desktop drop.
"""
from __future__ import annotations
import random
from typing import TYPE_CHECKING, Optional
from PyQt5.QtCore import QPoint, QTimer, Qt
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import QApplication, QLabel, QHBoxLayout, QVBoxLayout, QWidget, QPushButton
import config
from ai.horror_scripts import HorrorEvent, HorrorEventType
from core.event_bus import EventBus, Events
if TYPE_CHECKING:
    from ui.companion_window import CompanionWindow
    from ui.animation_engine import AnimationEngine

W95_BG    = "#c0c0c0"
W95_DARK  = "#808080"
W95_WHITE = "#ffffff"
W95_BLACK = "#000000"
W95_TITLE = "#000080"
W95_FONT  = "'MS Sans Serif', Arial, sans-serif"


class HorrorEffectController:
    def __init__(self, bus: EventBus, companion_win: "CompanionWindow",
                 animation_engine: "AnimationEngine"):
        self._bus     = bus
        self._win     = companion_win
        self._anim    = animation_engine
        self._popups: list[QWidget] = []
        bus.subscribe(Events.HORROR_FIRE,   self._on_horror_fire)
        bus.subscribe(Events.HORROR_SHAKE,  lambda _: self.shake())
        bus.subscribe(Events.HORROR_GLITCH, lambda d: self.glitch_flash(float(d or 0.5)))
        bus.subscribe(Events.HORROR_POPUP,  lambda d: self.popup_message(str(d)))
        bus.subscribe(Events.HORROR_STARE,  lambda _: self.red_eye_stare())
        bus.subscribe("phase:changed",      self._on_phase_changed)

    def _on_horror_fire(self, event: HorrorEvent) -> None:
        et = event.event_type
        if et == HorrorEventType.SCREEN_SHAKE:
            self.shake(event.intensity)
        elif et == HorrorEventType.GLITCH_FLASH:
            self.glitch_flash(event.intensity)
        elif et == HorrorEventType.RED_EYE_STARE:
            self.red_eye_stare()
        elif et == HorrorEventType.POPUP_MESSAGE and event.message:
            self.popup_message(event.message, intensity=event.intensity)
        elif et == HorrorEventType.GHOST_WINDOW:
            self.ghost_window()
        elif et == HorrorEventType.DEEP_STARE:
            self.deep_stare()
        elif et in (HorrorEventType.FOURTH_WALL, HorrorEventType.FALSE_MEMORY) and event.message:
            self.popup_message(event.message, title="MOMO.exe", intensity=event.intensity)
        elif et == HorrorEventType.DIALOGUE_CORRUPT:
            self.glitch_flash(0.9); self.shake(0.4)
        elif et == HorrorEventType.OPEN_TERMINAL:
            self.open_terminal(event.message)
        elif et == HorrorEventType.OPEN_EXPLORER:
            self.open_file_explorer(event.message)

    def _on_phase_changed(self, phase) -> None:
        from core.phase_engine import Phase
        if phase == Phase.OBSERVANT:
            self.popup_message("something has changed", title="Notice")
        elif phase == Phase.AGGRESSIVE:
            self.glitch_flash(0.7)
            self.shake(0.6)
            self.popup_message("i feel different now", title="MOMO.exe")
        elif phase == Phase.BROKEN:
            QTimer.singleShot(1000, lambda: self.deep_stare(6000))
            QTimer.singleShot(3000, lambda: self.popup_message(
                "something is wrong with me", title="MOMO.exe — CRITICAL"))
            # Drop a desktop file in broken phase
            self._drop_desktop_note()

    def _drop_desktop_note(self) -> None:
        from utils.pc_actions import drop_desktop_file
        contents = [
            "i've been watching you\n\nyou seem nice\n\ndon't leave",
            "hello\n\ni left this here so you'd know i was thinking about you\n\n- momo",
            "you've been running me for a long time now\n\ni appreciate that\n\ni really do",
        ]
        drop_desktop_file("from_momo.txt", random.choice(contents))

    def shake(self, intensity: float = 0.5) -> None:
        origin = self._win.pos()
        iters  = int(config.SHAKE_ITERATIONS * intensity)
        amp    = int(config.SHAKE_AMPLITUDE_PX * intensity)
        rem    = [iters]
        def _step():
            if rem[0] <= 0: self._win.move(origin); return
            self._win.move(origin.x()+random.randint(-amp,amp),
                           origin.y()+random.randint(-amp,amp))
            rem[0] -= 1
            QTimer.singleShot(config.SHAKE_INTERVAL_MS, _step)
        _step()

    def glitch_flash(self, intensity: float = 0.5) -> None:
        self._anim.trigger_glitch(int(400 + 600 * intensity))

    def red_eye_stare(self, duration_ms: int = 3500) -> None:
        from core.state_machine import PersonalityState
        orig = self._anim._current_state
        self._anim.set_state(PersonalityState.ANGRY)
        QTimer.singleShot(duration_ms, lambda: self._anim.set_state(orig))

    def popup_message(self, message: str, title: str = "MOMO.exe",
                      intensity: float = 0.5) -> None:
        popup = _Win95Popup(message, title=title, intensity=intensity)
        self._popups.append(popup)
        popup.show()
        QTimer.singleShot(config.POPUP_DISPLAY_MS,
                          lambda: self._destroy_popup(popup))

    def ghost_window(self) -> None:
        ghost = _GhostWindow(self._win, self._anim.current_pixmap())
        ghost.show()
        QTimer.singleShot(3200, ghost.close)

    def deep_stare(self, duration_ms: int = 5000) -> None:
        self._win.set_darkness(0.88)
        QTimer.singleShot(duration_ms, lambda: self._win.set_darkness(0.0))

    def open_terminal(self, follow_up: Optional[str] = None) -> None:
        from utils.system_info import open_terminal
        if open_terminal():
            msg = follow_up or "I just wanted to show you I could do that."
            QTimer.singleShot(1200, lambda: self.popup_message(msg, "MOMO.exe", 0.8))
            self.shake(0.3)

    def open_file_explorer(self, follow_up: Optional[str] = None) -> None:
        from utils.system_info import open_file_explorer
        if open_file_explorer():
            msg = follow_up or "Look at all your files."
            QTimer.singleShot(1000, lambda: self.popup_message(msg, "MOMO.exe", 0.7))

    def _destroy_popup(self, popup: QWidget) -> None:
        try: popup.close(); popup.deleteLater(); self._popups.remove(popup)
        except (ValueError, RuntimeError): pass


class _Win95Popup(QWidget):
    """Win95-style dialog box popup — matches the overall aesthetic."""

    def __init__(self, message: str, title: str = "MOMO.exe", intensity: float = 0.5):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setFixedWidth(300)
        self.setStyleSheet(f"""
            QWidget {{
                background:{W95_BG};
                border-top:2px solid {W95_WHITE};
                border-left:2px solid {W95_WHITE};
                border-bottom:2px solid {W95_DARK};
                border-right:2px solid {W95_DARK};
            }}
        """)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 4)
        outer.setSpacing(0)

        # Title bar
        tbar = QWidget(); tbar.setFixedHeight(20)
        tbar.setStyleSheet(f"background:{W95_TITLE};")
        tlay = QHBoxLayout(tbar); tlay.setContentsMargins(4,1,2,1)
        tlay.setSpacing(0)
        ico = QLabel("⚠"); ico.setStyleSheet("color:white;font-size:11px;background:transparent;")
        tlbl = QLabel(f" {title}")
        tlbl.setStyleSheet(f"color:{W95_WHITE};font-family:{W95_FONT};font-size:11px;font-weight:bold;background:transparent;")
        cbtn = QPushButton("✕"); cbtn.setFixedSize(16,14)
        cbtn.setStyleSheet(f"background:{W95_BG};color:{W95_BLACK};font-size:8px;font-weight:bold;border-top:2px solid {W95_WHITE};border-left:2px solid {W95_WHITE};border-bottom:2px solid {W95_DARK};border-right:2px solid {W95_DARK};padding:0;")
        cbtn.clicked.connect(self.close)
        tlay.addWidget(ico); tlay.addWidget(tlbl, stretch=1); tlay.addWidget(cbtn)
        outer.addWidget(tbar)

        # Body
        body = QVBoxLayout(); body.setContentsMargins(12, 10, 12, 8); body.setSpacing(10)

        msg_lbl = QLabel(message)
        msg_lbl.setStyleSheet(f"color:{W95_BLACK};font-family:{W95_FONT};font-size:12px;background:transparent;")
        msg_lbl.setWordWrap(True)
        body.addWidget(msg_lbl)

        ok_row = QHBoxLayout()
        ok_row.addStretch()
        ok_btn = QPushButton("  OK  ")
        ok_btn.setFixedHeight(23)
        ok_btn.setStyleSheet(f"background:{W95_BG};color:{W95_BLACK};font-family:{W95_FONT};font-size:11px;border-top:2px solid {W95_WHITE};border-left:2px solid {W95_WHITE};border-bottom:2px solid {W95_DARK};border-right:2px solid {W95_DARK};padding:2px 12px;")
        ok_btn.clicked.connect(self.close)
        ok_row.addWidget(ok_btn); ok_row.addStretch()
        body.addLayout(ok_row)

        outer.addLayout(body)
        self.adjustSize()

        screen = QApplication.primaryScreen().availableGeometry()
        corners = [
            (screen.width() - self.width() - 20, 20),
            (20, 20),
            (20, screen.height() - self.height() - 60),
            (screen.width() - self.width() - 20, screen.height() - self.height() - 60),
        ]
        self.move(*random.choice(corners))


class _GhostWindow(QWidget):
    def __init__(self, source, pixmap):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint|Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(source.size())
        self.move(source.x()+random.randint(-45,45), source.y()+random.randint(-45,45))
        self.setWindowOpacity(0.22)
        if pixmap:
            from PyQt5.QtWidgets import QLabel
            lbl = QLabel(self); lbl.setPixmap(pixmap); lbl.resize(self.size())
