"""
ui/floating_eye.py
------------------
Phase 3-4: A detached eye that breaks off the sprite and
slowly drifts toward the user's cursor across the screen.
Purely visual - no input interception, no system control.
"""
from __future__ import annotations
import math, random
from PyQt5.QtCore import Qt, QTimer, QPoint
from PyQt5.QtGui import QPainter, QColor, QBrush, QPen
from PyQt5.QtWidgets import QApplication, QWidget


class FloatingEye(QWidget):
    """Small always-on-top widget that follows the cursor at a creepy lag."""

    EYE_SIZE = 36

    def __init__(self, phase_engine, parent=None):
        super().__init__(parent)
        self._phase  = phase_engine
        self._x      = float(QApplication.primaryScreen().availableGeometry().center().x())
        self._y      = float(QApplication.primaryScreen().availableGeometry().center().y())
        self._blink  = False
        self._blink_t = 0

        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint |
            Qt.Tool | Qt.WindowTransparentForInput
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setFixedSize(self.EYE_SIZE, self.EYE_SIZE)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(50)   # 20 fps is enough for creep

    def _tick(self):
        cursor  = QApplication.desktop().cursor().pos()
        cx, cy  = float(cursor.x()), float(cursor.y())

        # Lag speed scales with phase intensity
        speed   = 0.025 + 0.06 * self._phase.glitch_intensity()

        # Add slight phase-jitter wobble in broken phase
        jitter  = self._phase.jitter_px()
        cx      += random.uniform(-jitter, jitter)
        cy      += random.uniform(-jitter, jitter)

        self._x += (cx - self._x) * speed
        self._y += (cy - self._y) * speed

        # Occasional blink
        self._blink_t += 1
        if self._blink_t > 40 + random.randint(0, 60):
            self._blink   = True
            self._blink_t = 0
            QTimer.singleShot(80, self._unblink)

        self.move(int(self._x - self.EYE_SIZE // 2),
                  int(self._y - self.EYE_SIZE // 2))
        self.update()

    def _unblink(self):
        self._blink = False
        self.update()

    def paintEvent(self, event):
        p     = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r     = self.EYE_SIZE // 2
        cx, cy = r, r

        # Sclera (white of eye)
        p.setBrush(QBrush(QColor(245, 240, 255)))
        p.setPen(QPen(QColor(30, 10, 50), 1))
        p.drawEllipse(cx - r + 2, cy - r + 2, (r - 2)*2, (r - 2)*2)

        if not self._blink:
            # Iris — purple, glows more in broken phase
            intensity = self._phase.glitch_intensity()
            iris_r    = int(r * 0.55 + intensity * 3)
            iris_col  = QColor(
                int(120 + intensity * 80),
                int(20),
                int(200 + intensity * 55)
            )
            p.setBrush(QBrush(iris_col))
            p.setPen(Qt.NoPen)
            p.drawEllipse(cx - iris_r, cy - iris_r, iris_r*2, iris_r*2)

            # Pupil
            pupil_r = max(3, int(iris_r * 0.5))
            p.setBrush(QBrush(QColor(5, 0, 10)))
            p.drawEllipse(cx - pupil_r, cy - pupil_r, pupil_r*2, pupil_r*2)

            # Catchlight
            p.setBrush(QBrush(QColor(255, 255, 255, 180)))
            p.drawEllipse(cx + 2, cy - iris_r + 2, 5, 5)
        else:
            # Blink — just a line
            p.setPen(QPen(QColor(30, 10, 50), 2))
            p.drawLine(cx - r + 4, cy, cx + r - 4, cy)

    def stop(self):
        self._timer.stop()
        self.hide()
