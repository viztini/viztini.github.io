from __future__ import annotations
import random
from PyQt5.QtCore import Qt, QTimer, QPoint, pyqtSignal
from PyQt5.QtGui import QTextCursor
from PyQt5.QtWidgets import (
    QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTextEdit, QVBoxLayout, QWidget
)
from ai.games_engine import GamesEngine, GameType
import config

W95_BG    = "#c0c0c0"
W95_DARK  = "#808080"
W95_WHITE = "#ffffff"
W95_BLACK = "#000000"
W95_TITLE = "#000080"
W95_FONT  = "'MS Sans Serif', 'Arial', sans-serif"
W95_MOMO  = "#7b2fbe"

BTN_STYLE = f"""
    QPushButton {{
        background:{W95_BG}; color:{W95_BLACK};
        font-family:{W95_FONT}; font-size:11px;
        border-top:2px solid {W95_WHITE};
        border-left:2px solid {W95_WHITE};
        border-bottom:2px solid {W95_DARK};
        border-right:2px solid {W95_DARK};
        padding:4px 8px;
    }}
    QPushButton:pressed {{
        border-top:2px solid {W95_DARK};  border-left:2px solid {W95_DARK};
        border-bottom:2px solid {W95_WHITE}; border-right:2px solid {W95_WHITE};
    }}
    QPushButton:hover {{ background:#d4d4d4; }}
"""

class GamesWindow(QWidget):
    closed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._engine   = GamesEngine()
        self._thinking = False
        self._tw_timer = QTimer(self)
        self._tw_timer.timeout.connect(self._tw_tick)
        self._tw_text  = ""
        self._tw_idx   = 0
        self._drag_pos = None
        self._build_ui()

    def _build_ui(self):
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setFixedSize(440, 540)

        outer = QWidget(self)
        outer.setGeometry(0, 0, 440, 540)
        outer.setStyleSheet(f"background:{W95_BG}; "
                            f"border-top:2px solid {W95_WHITE}; "
                            f"border-left:2px solid {W95_WHITE}; "
                            f"border-bottom:2px solid {W95_DARK}; "
                            f"border-right:2px solid {W95_DARK};")

        layout = QVBoxLayout(outer)
        layout.setContentsMargins(4, 4, 4, 6)
        layout.setSpacing(4)

        # Title bar
        tbar = QWidget(); tbar.setFixedHeight(22)
        tbar.setStyleSheet(f"background:{W95_TITLE};")
        tbar.mousePressEvent   = lambda e: setattr(self, "_drag_pos",
            e.globalPos() - self.frameGeometry().topLeft()) if e.button()==Qt.LeftButton else None
        tbar.mouseMoveEvent    = lambda e: self.move(e.globalPos()-self._drag_pos) \
            if e.buttons()&Qt.LeftButton and self._drag_pos else None
        tbar.mouseReleaseEvent = lambda e: setattr(self, "_drag_pos", None)
        tlay = QHBoxLayout(tbar); tlay.setContentsMargins(3,2,2,2); tlay.setSpacing(0)
        tlay.addWidget(QLabel("🐙 ", styleSheet="color:white;background:transparent;font-size:11px;"))
        tlbl = QLabel(" MOMO Games"); tlbl.setStyleSheet(f"color:{W95_WHITE};font-family:{W95_FONT};font-size:11px;font-weight:bold;background:transparent;")
        tlay.addWidget(tlbl, stretch=1)
        cbtn = QPushButton("✕"); cbtn.setFixedSize(18,16)
        cbtn.setStyleSheet(f"background:{W95_BG};color:{W95_BLACK};font-size:9px;font-weight:bold;border-top:2px solid {W95_WHITE};border-left:2px solid {W95_WHITE};border-bottom:2px solid {W95_DARK};border-right:2px solid {W95_DARK};padding:0;")
        cbtn.clicked.connect(self.close)
        tlay.addWidget(cbtn)
        layout.addWidget(tbar)

        # Game buttons
        grid = QGridLayout(); grid.setSpacing(4)
        games = [
            ("Trivia Quiz",      GameType.TRIVIA),
            ("20 Questions",     GameType.TWENTY_Q),
            ("Word Association", GameType.WORD_ASSOC),
            ("Would You Rather", GameType.WOULD_RATHER),
            ("Riddles",          GameType.RIDDLES),
        ]
        for i, (label, gtype) in enumerate(games):
            btn = QPushButton(label); btn.setStyleSheet(BTN_STYLE)
            btn.clicked.connect(lambda _, g=gtype: self._start_game(g))
            grid.addWidget(btn, i//2, i%2)
        stop_btn = QPushButton("Stop Game"); stop_btn.setStyleSheet(BTN_STYLE.replace(W95_BG,"#e0c0c0"))
        stop_btn.clicked.connect(self._stop_game)
        grid.addWidget(stop_btn, 2, 1)
        layout.addLayout(grid)

        # Separator line
        sep = QWidget(); sep.setFixedHeight(2)
        sep.setStyleSheet(f"background:{W95_DARK};")
        layout.addWidget(sep)

        # Log
        self._log = QTextEdit(); self._log.setReadOnly(True)
        self._log.setStyleSheet(f"""
            QTextEdit {{
                background:{W95_WHITE}; color:{W95_BLACK};
                font-family:'Courier New',monospace; font-size:12px;
                border-top:2px solid {W95_DARK}; border-left:2px solid {W95_DARK};
                border-bottom:2px solid {W95_WHITE}; border-right:2px solid {W95_WHITE};
                padding:4px;
            }}
            QScrollBar:vertical {{ background:{W95_BG}; width:16px; }}
            QScrollBar::handle:vertical {{
                background:{W95_BG};
                border-top:2px solid {W95_WHITE}; border-left:2px solid {W95_WHITE};
                border-bottom:2px solid {W95_DARK}; border-right:2px solid {W95_DARK};
                min-height:20px;
            }}
        """)
        layout.addWidget(self._log, stretch=1)

        # Status
        self._status = QLabel("Select a game to begin")
        self._status.setStyleSheet(f"background:{W95_BG};color:{W95_DARK};font-family:{W95_FONT};font-size:11px;border-top:1px solid {W95_DARK};padding:1px 4px;")
        layout.addWidget(self._status)

        # Input row
        row = QHBoxLayout(); row.setSpacing(4)
        lbl = QLabel("Answer:"); lbl.setStyleSheet(f"color:{W95_BLACK};font-family:{W95_FONT};font-size:11px;")
        self._input = QLineEdit()
        self._input.setStyleSheet(f"background:{W95_WHITE};color:{W95_BLACK};font-family:{W95_FONT};font-size:12px;border-top:2px solid {W95_DARK};border-left:2px solid {W95_DARK};border-bottom:2px solid {W95_WHITE};border-right:2px solid {W95_WHITE};padding:2px 4px;")
        self._input.returnPressed.connect(self._on_submit)
        ok_btn = QPushButton("OK"); ok_btn.setStyleSheet(BTN_STYLE); ok_btn.setFixedWidth(50)
        ok_btn.clicked.connect(self._on_submit)
        row.addWidget(lbl); row.addWidget(self._input, stretch=1); row.addWidget(ok_btn)
        layout.addLayout(row)

        self._print_momo("Pick a game from the buttons above. I'm ready when you are.")

    def _start_game(self, gtype: GameType):
        intro = self._engine.start_game(gtype)
        self._print_momo(intro)
        self._status.setText(f"Playing: {gtype.name.replace('_',' ').title()}")
        self._input.setFocus()

    def _stop_game(self):
        msg = self._engine.stop() if self._engine.is_active() else "No game is running."
        self._print_momo(msg)
        self._status.setText("Select a game to begin")

    def _on_submit(self):
        text = self._input.text().strip()
        if not text or self._thinking or self._tw_timer.isActive():
            return
        self._input.clear()
        self._print_user(text)
        if self._engine.is_active():
            self._print_momo(self._engine.handle_input(text))
        else:
            self._print_momo("Choose a game from the buttons first!")

    def _print_momo(self, text: str):
        self._append_raw(f'<span style="color:{W95_MOMO};font-weight:bold;">[MOMO]</span> ')
        self._tw_text = text; self._tw_idx = 0
        self._thinking = True; self._input.setEnabled(False)
        self._tw_timer.start(20)

    def _tw_tick(self):
        if self._tw_idx >= len(self._tw_text):
            self._tw_timer.stop()
            self._append_raw("<br>")
            self._thinking = False          # BUG FIX
            self._input.setEnabled(True)
            self._input.setFocus()
            return
        ch = self._tw_text[self._tw_idx]; self._tw_idx += 1
        esc = ch.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace(" ","&nbsp;").replace("\n","<br>")
        self._append_raw(f'<span style="color:{W95_MOMO};">{esc}</span>')
        delay = 20 + random.randint(-6,6)
        if ch in ".!?": delay += 150
        elif ch in ",;:": delay += 50
        self._tw_timer.setInterval(max(6,delay))

    def _print_user(self, text: str):
        esc = text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
        self._append_raw(f'<span style="color:#000060;font-weight:bold;">[You]</span> <span style="color:{W95_BLACK};">{esc}</span><br>')

    def _append_raw(self, html: str):
        cur = self._log.textCursor(); cur.movePosition(QTextCursor.End)
        cur.insertHtml(html)
        self._log.verticalScrollBar().setValue(self._log.verticalScrollBar().maximum())

    def closeEvent(self, event):
        self._tw_timer.stop(); self._thinking = False
        self.closed.emit(); event.accept()
